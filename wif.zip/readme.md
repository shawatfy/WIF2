# WIF Trading Bot 3.0

A complete end-to-end crypto trading bot with backtesting and live trading capabilities.

## Features

- **Multi-asset trading** (WIF/USDT, PEPE/USDT, SHIB/USDT)
- **Backtest environment** fully separated from live runtime
- **Telegram control** for real-time management
- **Async-safe design** with no nested event loops
- **Modular architecture** ready for SaaS expansion

## Architecture

The system is built with complete separation between backtesting and live trading:

- **Backtest Layer**: Synchronous, uses historical data
- **Live Layer**: Asynchronous, uses real-time market data

## Strategies

1. **DipHunter**: Mean reversion on RSI oversold + deviation below VWAP
2. **TrendSurfer**: EMA alignment + UT Bot trend + StochRSI pullback  
3. **BreakoutSniper**: Breakout above swing high + volume filter

## Quick Start

1. Clone and install dependencies:
```bash
pip install -r requirements.txt