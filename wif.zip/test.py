import asyncio
from src.services.market_data import MarketDataService
from src.strategies.donchian_atr_live import DonchianATRLive

async def test_signal():
    data = await MarketDataService().fetch_ohlcv("WIF/USDT", "1m", 250)
    s = DonchianATRLive()
    result = await s.generate_signal_live(data, {"balance": 1000})
    print("\n🧠 Strategy Output:\n", result)

if __name__ == "__main__":
    asyncio.run(test_signal())