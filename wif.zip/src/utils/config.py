import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    """Configuration management"""
    
    # Environment
    ENV = os.getenv('ENV', 'dev')
    LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
    
    # Exchange
    EXCHANGE = os.getenv('EXCHANGE', 'binance')
    BINANCE_API_KEY = os.getenv('BINANCE_API_KEY')
    BINANCE_API_SECRET = os.getenv('BINANCE_API_SECRET')
    
    # Telegram
    TELEGRAM_BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN')
    
    # Database
    DB_URL = os.getenv('DB_URL', 'sqlite:///wifbot.db')
    
    # Risk Management
    #
    # ``RISK_PER_TRADE`` represents the fraction of your account equity you are
    # willing to risk on any single trade (e.g. ``0.01`` = 1%).  The bot will
    # compute a position size based on your account balance and the stop loss
    # distance so that the potential loss does not exceed this fraction.  It
    # should not be mistaken for a fixed quantity of the asset.  The default
    # values are conservative and can be overridden via environment variables.
    RISK_PER_TRADE = float(os.getenv('RISK_PER_TRADE', 0.01))
    DAILY_LOSS_LIMIT = float(os.getenv('DAILY_LOSS_LIMIT', 0.03))
    MAX_CONCURRENT_TRADES = int(os.getenv('MAX_CONCURRENT_TRADES', 2))
    
    # Trading
    SYMBOLS = os.getenv('SYMBOLS', 'WIF/USDT,PEPE/USDT,SHIB/USDT').split(',')
    TIMEFRAMES = os.getenv('TIMEFRAMES', '1m,5m,15m,1h').split(',')
    DRY_RUN = os.getenv('DRY_RUN', 'true').lower() == 'true'
    
    @classmethod
    def validate(cls):
        """Validate required configuration"""
        missing = []
        if not cls.TELEGRAM_BOT_TOKEN:
            missing.append('TELEGRAM_BOT_TOKEN')
        if not cls.BINANCE_API_KEY and not cls.DRY_RUN:
            missing.append('BINANCE_API_KEY')
        if not cls.BINANCE_API_SECRET and not cls.DRY_RUN:
            missing.append('BINANCE_API_SECRET')
        
        if missing:
            raise ValueError(f"Missing required environment variables: {', '.join(missing)}")
    
    @classmethod
    def get_telegram_config(cls):
        return {
            'token': cls.TELEGRAM_BOT_TOKEN
        }
    
    @classmethod
    def get_exchange_config(cls):
        return {
            'apiKey': cls.BINANCE_API_KEY,
            'secret': cls.BINANCE_API_SECRET,
            'sandbox': cls.DRY_RUN,
            'verbose': False
        }