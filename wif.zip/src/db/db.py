import os
import sys
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from contextlib import contextmanager
from .models import Base
from src.utils.logger import setup_logger

logger = setup_logger('db')

class DatabaseManager:
    def __init__(self, db_url=None):
        self.db_url = db_url or os.getenv('DB_URL', 'sqlite:///wifbot.db')
        self.engine = create_engine(self.db_url, echo=False)
        self.SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=self.engine)
    
    def init_db(self):
        """Initialize database tables"""
        try:
            Base.metadata.create_all(bind=self.engine)
            logger.info("Database tables created successfully")
            return True
        except Exception as e:
            logger.error(f"Error initializing database: {e}")
            return False
    
    @contextmanager
    def session_scope(self):
        """Provide a transactional scope around a series of operations."""
        session = self.SessionLocal()
        try:
            yield session
            session.commit()
        except Exception as e:
            session.rollback()
            logger.error(f"Database session error: {e}")
            raise
        finally:
            session.close()

# Global database instance
db_manager = DatabaseManager()

def get_db():
    return db_manager

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--init", action="store_true", help="Initialize database")
    args = parser.parse_args()
    
    if args.init:
        db_manager.init_db()

        # === compatibility alias for external modules ===
session_scope = db_manager.session_scope