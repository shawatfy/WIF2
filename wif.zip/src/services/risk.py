from typing import Dict, Any, List
from datetime import datetime, timedelta
from src.utils.logger import setup_logger
from src.utils.config import Config
from src.db.db import db_manager

logger = setup_logger('risk')

class RiskManager:
    """Risk management service"""
    
    def __init__(self):
        self.risk_per_trade = Config.RISK_PER_TRADE
        self.daily_loss_limit = Config.DAILY_LOSS_LIMIT
        self.max_concurrent_trades = Config.MAX_CONCURRENT_TRADES
    
    async def validate_signal(self, signal: Dict[str, Any], user_id: int = 1) -> Dict[str, Any]:
        """
        Validate trading signal against risk rules
        
        Returns:
            Dict with 'approved' boolean and 'reason' if rejected
        """
        # Check concurrent trades
        if not await self._check_concurrent_trades(user_id):
            return {
                'approved': False,
                'reason': f'Maximum concurrent trades ({self.max_concurrent_trades}) reached'
            }
        
        # Check daily loss limit
        if not await self._check_daily_loss_limit(user_id):
            return {
                'approved': False,
                'reason': 'Daily loss limit reached'
            }
        
        # Check position size
        position_validation = await self._validate_position_size(signal, user_id)
        if not position_validation['approved']:
            return position_validation
        
        # Check market conditions
        market_validation = await self._validate_market_conditions(signal)
        if not market_validation['approved']:
            return market_validation
        
        return {'approved': True, 'reason': 'Signal approved'}
    
    async def _check_concurrent_trades(self, user_id: int) -> bool:
        """Check if maximum concurrent trades reached"""
        with db_manager.session_scope() as session:
            from src.db.models import Trade
            open_trades = session.query(Trade).filter(
                Trade.user_id == user_id,
                Trade.status == 'open'
            ).count()
            
            return open_trades < self.max_concurrent_trades
    
    async def _check_daily_loss_limit(self, user_id: int) -> bool:
        """Check if daily loss limit reached"""
        today = datetime.utcnow().date()
        
        with db_manager.session_scope() as session:
            from src.db.models import Trade
            today_trades = session.query(Trade).filter(
                Trade.user_id == user_id,
                Trade.closed_at >= today,
                Trade.status == 'closed'
            ).all()
            
            total_loss = sum(trade.pnl for trade in today_trades if trade.pnl < 0)
            
            # Get current portfolio value (simplified)
            portfolio_value = 1000  # This should come from balance service
            
            loss_percent = abs(total_loss) / portfolio_value if portfolio_value > 0 else 0
            
            return loss_percent < self.daily_loss_limit
    
    async def _validate_position_size(self, signal: Dict[str, Any], user_id: int) -> Dict[str, Any]:
        """
        Validate position size against risk rules.

        The ``size`` field on incoming signals may represent either a
        percentage of portfolio equity (0–1) or an absolute quantity of the
        asset depending on the context.  If ``size`` is omitted or zero the
        execution engine will compute an appropriate quantity based on
        ``RISK_PER_TRADE`` and the stop loss distance.  We therefore only
        enforce the ``RISK_PER_TRADE`` cap when the provided ``size`` is
        itself a fraction (i.e. less than one).  Absolute quantities are
        permitted and further checked when calculating position size.

        Returns:
            A dict with ``approved`` boolean and an optional ``reason``.
        """
        position_size = float(signal.get('size', 0) or 0)
        # Skip validation when size is zero or negative; the engine will compute
        if position_size <= 0:
            return {'approved': True}
        # When risk_per_trade is expressed as a fraction (< 1.0) and the user
        # specified size also appears to be a fraction (< 1.0), ensure it does
        # not exceed the risk limit.  For absolute position sizes (>= 1) we
        # defer checking to the sizing calculation.
        if self.risk_per_trade < 1.0 and position_size < 1.0:
            if position_size > self.risk_per_trade:
                return {
                    'approved': False,
                    'reason': f'Position size {position_size} exceeds risk per trade {self.risk_per_trade}'
                }
        return {'approved': True}
    
    async def _validate_market_conditions(self, signal: Dict[str, Any]) -> Dict[str, Any]:
        """Validate market conditions (placeholder for future enhancements)"""
        # Add market volatility checks, volume checks, etc.
        return {'approved': True}
    
    def calculate_position_size(self, portfolio_value: float, entry_price: float, stop_loss: float) -> float:
        """Calculate position size based on risk parameters"""
        risk_amount = portfolio_value * self.risk_per_trade
        price_diff = abs(entry_price - stop_loss)
        
        if price_diff == 0:
            return 0
        
        position_size = risk_amount / price_diff
        return min(position_size, portfolio_value * 0.1)  # Max 10% of portfolio