import ccxt
import pandas as pd
import asyncio
from typing import List, Dict, Any
from src.utils.logger import setup_logger
from src.utils.config import Config

logger = setup_logger('market_data')

class MarketDataService:
    """Market data service for fetching OHLCV data"""
    
    def __init__(self):
        self.exchange = self._init_exchange()
        self.cache = {}
    
    def _init_exchange(self):
        """Initialize exchange connection for spot trading.

        This method explicitly enables rate limiting and forces the default
        market type to ``spot``.  If API credentials are not provided and
        ``DRY_RUN`` is true the exchange will operate in public mode for
        market data requests.  When ``DRY_RUN`` is false both the API key
        and secret must be present; missing values will cause validation to
        fail before this method is called (see ``Config.validate``).
        """
        exchange_class = getattr(ccxt, Config.EXCHANGE)
        exchange_config = {
            'apiKey': Config.BINANCE_API_KEY,
            'secret': Config.BINANCE_API_SECRET,
            'sandbox': Config.DRY_RUN,
            'verbose': False,
            'enableRateLimit': True,
            'options': {'defaultType': 'spot'},
        }
        return exchange_class(exchange_config)

    def _normalize_symbol(self, symbol: str) -> str:
        """
        Normalise trading symbols into CCXT format.  If a slash is already
        present the symbol is returned unchanged.  Otherwise the function
        searches for a recognised quote asset (e.g. USDT, USDC, BTC, ETH)
        at the end of the string and inserts a slash before it.  Symbols are
        always upper‑cased.

        Args:
            symbol: Raw symbol as provided by the user (e.g. ``WIFUSDT`` or
                ``wif/usdt``).

        Returns:
            Symbol formatted for CCXT (``WIF/USDT``) or the original string
            if no known quote asset is found.
        """
        if not symbol:
            return symbol
        if '/' in symbol:
            return symbol.upper()
        symbol = symbol.upper()
        quote_assets = ["USDT", "USDC", "BTC", "ETH", "BUSD"]
        for quote in quote_assets:
            if symbol.endswith(quote):
                base = symbol[:-len(quote)]
                return f"{base}/{quote}"
        return symbol
    
    async def fetch_ohlcv(self, symbol: str, timeframe: str = '1m', limit: int = 100) -> pd.DataFrame:
        """
        Fetch OHLCV candlestick data asynchronously.

        The provided ``symbol`` is first normalised to ensure it is in the
        correct CCXT format.  Data is returned as a pandas ``DataFrame`` with
        timestamp index.  In the event of an error an empty DataFrame is
        returned and the exception is logged.

        Args:
            symbol: Trading pair in raw or CCXT format (e.g. ``WIFUSDT`` or
                ``WIF/USDT``).
            timeframe: Candlestick timeframe (e.g. ``1m``, ``5m``).
            limit: Maximum number of rows to return.

        Returns:
            DataFrame indexed by timestamp with columns ``open``, ``high``,
            ``low``, ``close`` and ``volume``.  Empty on failure.
        """
        try:
            norm_symbol = self._normalize_symbol(symbol)
            ohlcv = await asyncio.to_thread(
                self.exchange.fetch_ohlcv,
                norm_symbol,
                timeframe,
                limit=limit,
            )
            df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
            df.set_index('timestamp', inplace=True)
            return df
        except Exception as e:
            logger.error(f"Error fetching OHLCV for {symbol} {timeframe}: {e}")
            return pd.DataFrame()
    
    async def fetch_current_price(self, symbol: str) -> float:
        """
        Fetch the latest trade price for a symbol.

        Args:
            symbol: Trading pair in raw or CCXT format.

        Returns:
            The last traded price or 0.0 if retrieval fails.
        """
        try:
            norm_symbol = self._normalize_symbol(symbol)
            ticker = await asyncio.to_thread(self.exchange.fetch_ticker, norm_symbol)
            return float(ticker.get('last', 0.0))
        except Exception as e:
            logger.error(f"Error fetching price for {symbol}: {e}")
            return 0.0
    
    async def fetch_multiple_ohlcv(self, symbols: List[str], timeframes: List[str], limit: int = 100) -> Dict[str, Dict[str, pd.DataFrame]]:
        """Fetch OHLCV data for multiple symbols and timeframes"""
        tasks = []
        
        for symbol in symbols:
            for timeframe in timeframes:
                tasks.append(self.fetch_ohlcv(symbol, timeframe, limit))
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        data = {}
        result_idx = 0
        for symbol in symbols:
            data[symbol] = {}
            for timeframe in timeframes:
                if isinstance(results[result_idx], Exception):
                    logger.error(f"Failed to fetch {symbol} {timeframe}: {results[result_idx]}")
                    data[symbol][timeframe] = pd.DataFrame()
                else:
                    data[symbol][timeframe] = results[result_idx]
                result_idx += 1
        
        return data