import ccxt
import asyncio
from typing import Dict, Any, Optional, List
from src.utils.logger import setup_logger
from src.utils.config import Config

logger = setup_logger('binance_adapter')

class BinanceAdapter:
    """Adapter for Binance exchange operations"""
    
    def __init__(self):
        self.exchange = self._init_exchange()
        self.dry_run = Config.DRY_RUN
        # list of quote currencies used to normalise symbols
        self.quote_assets = ["USDT", "USDC", "BTC", "ETH"]

    def _normalize_symbol(self, symbol: str) -> str:
        """
        Normalise symbols to CCXT format.  If the symbol already contains a slash
        it is returned unchanged.  Otherwise the method attempts to insert a slash
        before a recognised quote asset (e.g. ``WIFUSDT`` → ``WIF/USDT``).
        """
        if "/" in symbol:
            return symbol
        symbol = symbol.upper()
        for quote in self.quote_assets:
            if symbol.endswith(quote):
                base = symbol[:-len(quote)]
                return f"{base}/{quote}"
        return symbol

    async def _ccxt_call(self, func, *args, timeout: float = 10.0, retries: int = 3, **kwargs):
        """
        Wrap CCXT synchronous calls with timeout and retry logic.

        Binance may return HTTP 429 (Too Many Requests) or other 5xx server
        errors. This wrapper implements exponential backoff between retries
        and surfaces the last exception to callers if all attempts fail.
        """
        attempt = 0
        last_exc = None
        while attempt < retries:
            try:
                return await asyncio.wait_for(
                    asyncio.to_thread(func, *args, **kwargs),
                    timeout=timeout
                )
            except Exception as exc:
                last_exc = exc
                msg = str(exc).lower()
                if '429' in msg or 'too many requests' in msg:
                    logger.warning(f"Binance rate limit hit on {func.__name__}; retrying after backoff")
                elif any(code in msg for code in ['500', '502', '503', '504', 'server error', 'service unavailable']):
                    logger.warning(f"Binance server error on {func.__name__}; retrying after backoff")
                else:
                    logger.warning(f"CCXT call {func.__name__} failed on attempt {attempt+1}/{retries}: {exc}")
                attempt += 1
                await asyncio.sleep(min(60, 2 ** attempt))
        if last_exc:
            raise last_exc
        raise Exception(f"Unexpected failure in _ccxt_call for {func.__name__}")
    
    def _init_exchange(self):
        """Initialize Binance exchange in spot mode.

        Always enable rate limiting and explicitly set the default type to
        spot to ensure that all requests interact with the spot market.
        """
        exchange_config = {
            'apiKey': Config.BINANCE_API_KEY,
            'secret': Config.BINANCE_API_SECRET,
            'sandbox': Config.DRY_RUN,
            'verbose': False,
            'enableRateLimit': True,
            'options': {'defaultType': 'spot'}
        }
        return ccxt.binance(exchange_config)
    
    async def create_order(self, symbol: str, order_type: str, side: str, amount: float,
                          price: Optional[float] = None, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Create an order asynchronously with normalisation and retry.

        The optional ``params`` dictionary can include exchange-specific fields
        such as ``clientOrderId``. In dry-run mode a mock order is returned
        without calling the exchange.
        """
        params = params or {}
        if self.dry_run:
            logger.info(f"DRY RUN: Would create {side} {order_type} order for {amount} {symbol} at {price}")
            return {
                'id': 'dry_run',
                'status': 'closed',
                'symbol': symbol,
                'side': side,
                'amount': amount,
                'price': price or 0,
                'clientOrderId': params.get('clientOrderId')
            }
        try:
            norm_symbol = self._normalize_symbol(symbol)
            order = await self._ccxt_call(
                self.exchange.create_order,
                norm_symbol,
                order_type,
                side,
                amount,
                price,
                params
            )
            logger.info(f"Order created: {order.get('id')} for {amount} {norm_symbol}")
            return order
        except Exception as e:
            logger.error(f"Error creating order for {symbol}: {e}")
            raise

    async def fetch_current_price(self, symbol: str) -> float:
        """Return the last traded price for a symbol."""
        ticker = await self.fetch_ticker(symbol)
        return ticker.get('last', 0.0)
    
    async def create_market_order(
        self, symbol: str, side: str, amount: float, params: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Create a market order.

        Args:
            symbol: Trading pair in CCXT or raw format.
            side: ``buy`` or ``sell``.
            amount: Quantity to trade.
            params: Optional parameters passed through to the exchange.

        Returns:
            Order dictionary from the exchange or mock order in dry-run.
        """
        return await self.create_order(symbol, 'market', side, amount, None, params)
    
    async def create_limit_order(
        self, symbol: str, side: str, amount: float, price: float, params: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Create a limit order.

        Args:
            symbol: Trading pair in CCXT or raw format.
            side: ``buy`` or ``sell``.
            amount: Quantity to trade.
            price: Limit price.
            params: Optional parameters passed through to the exchange.

        Returns:
            Order dictionary from the exchange or mock order in dry-run.
        """
        return await self.create_order(symbol, 'limit', side, amount, price, params)
    
    async def cancel_order(self, symbol: str, order_id: str) -> bool:
        """Cancel order"""
        if self.dry_run:
            logger.info(f"DRY RUN: Would cancel order {order_id} for {symbol}")
            return True
        
        try:
            # normalise symbol and wrap ccxt call
            symbol = self._normalize_symbol(symbol)
            await self._ccxt_call(self.exchange.cancel_order, order_id, symbol)
            logger.info(f"Order cancelled: {order_id}")
            return True
        except Exception as e:
            logger.error(f"Error cancelling order {order_id}: {e}")
            return False
    
    async def fetch_balance(self) -> Dict[str, float]:
        """Fetch account balance"""
        if self.dry_run:
            return {'USDT': 1000.0, 'BTC': 0.01}  # Mock balance for dry run
        
        try:
            balance = await self._ccxt_call(self.exchange.fetch_balance)
            return balance['free']
        except Exception as e:
            logger.error(f"Error fetching balance: {e}")
            raise
    
    async def fetch_open_orders(self, symbol: str = None) -> List[Dict[str, Any]]:
        """Fetch open orders"""
        if self.dry_run:
            return []
        
        try:
            norm_symbol = self._normalize_symbol(symbol) if symbol else None
            orders = await self._ccxt_call(self.exchange.fetch_open_orders, norm_symbol)
            return orders
        except Exception as e:
            logger.error(f"Error fetching open orders: {e}")
            raise
    
    async def fetch_ticker(self, symbol: str) -> Dict[str, Any]:
        """Fetch ticker data"""
        try:
            norm_symbol = self._normalize_symbol(symbol)
            ticker = await self._ccxt_call(self.exchange.fetch_ticker, norm_symbol)
            return ticker
        except Exception as e:
            logger.error(f"Error fetching ticker for {symbol}: {e}")
            raise