import asyncio
from typing import Dict, Any, List
from datetime import datetime
from src.utils.logger import setup_logger
from src.utils.config import Config
from src.db.db import db_manager
from .binance_adapter import BinanceAdapter
from .risk import RiskManager

logger = setup_logger('exec_engine')

class ExecutionEngine:
    """Trade execution engine"""
    
    def __init__(self):
        self.exchange = BinanceAdapter()
        self.risk_manager = RiskManager()
        self.active_orders = {}
    
    async def execute_signal(self, signal: Dict[str, Any], user_id: int = 1) -> Dict[str, Any]:
        """Execute a trading signal with risk checks and idempotent order IDs.

        The execution flow performs the following steps:

        1. Validate the signal against the risk manager.
        2. Normalise and compute the position size if not provided.
        3. Fetch the current price from the exchange.
        4. Generate a deterministic client order identifier to prevent
           duplicate orders across restarts.
        5. Submit a market order via the adapter with the client ID.
        6. Record the trade and set any associated stop-loss / take-profit orders.
        """
        try:
            # 1) Validate with risk manager
            risk_check = await self.risk_manager.validate_signal(signal, user_id)
            if not risk_check['approved']:
                logger.warning(f"Signal rejected: {risk_check['reason']}")
                return {
                    'success': False,
                    'reason': risk_check['reason'],
                    'signal': signal
                }

            symbol = signal['symbol']
            side = signal['side'].lower()

            # 2) Determine trade size. If size is not provided or zero, compute based on risk.
            size = float(signal.get('size') or 0)

            # 3) Fetch current price for sizing and execution
            current_price = await self.exchange.fetch_current_price(symbol)

            # Compute position size dynamically if not specified or if greater than risk_per_trade
            if size <= 0:
                try:
                    balance = await self.exchange.fetch_balance()
                    portfolio_value = balance.get('USDT', 0.0)
                except Exception:
                    portfolio_value = 0.0
                # Use provided stop-loss or default 2% below current price
                stop_price = signal.get('sl') or current_price * (1 - self.risk_manager.risk_per_trade)
                computed_size = self.risk_manager.calculate_position_size(
                    portfolio_value, current_price, stop_price
                )
                size = computed_size
                signal['size'] = size

            # 4) Build idempotent client order ID.
            #
            # To prevent accidental duplicate orders after a restart we use a
            # deterministic clientOrderId derived from the user, symbol,
            # timeframe, strategy and a coarse time bucket.  The timeframe is
            # included because different chart resolutions may produce
            # independent signals.  A 60‑second bucket is used to group
            # multiple signals generated within the same minute into a
            # single order.
            import time, hashlib
            ts_bucket = int(time.time() // 60)
            strategy_name = signal.get('meta', {}).get('strategy', signal.get('strategy', ''))
            timeframe = signal.get('timeframe', '')
            base_str = f"{user_id}-{symbol}-{timeframe}-{strategy_name}-{ts_bucket}"
            client_order_id = hashlib.md5(base_str.encode()).hexdigest()[:20]
            params = {'clientOrderId': client_order_id}

            # 5) Submit market order
            if side == 'buy':
                order_result = await self.exchange.create_market_order(symbol, 'buy', size, params)
            else:
                order_result = await self.exchange.create_market_order(symbol, 'sell', size, params)

            # 6) Record the trade
            trade_record = await self._record_trade(signal, order_result, user_id, current_price)

            # 7) Submit stop-loss and take-profit orders (only for buys on spot)
            sl_tp_orders: List[Dict[str, Any]] = []
            if signal.get('sl') and side == 'buy':
                sl_client_id = hashlib.md5(f"sl-{client_order_id}".encode()).hexdigest()[:20]
                sl_order = await self._set_stop_loss(symbol, size, signal['sl'], trade_record.id, sl_client_id)
                if sl_order:
                    sl_tp_orders.append(sl_order)
            if signal.get('tp') and side == 'buy':
                tp_client_id = hashlib.md5(f"tp-{client_order_id}".encode()).hexdigest()[:20]
                tp_order = await self._set_take_profit(symbol, size, signal['tp'], trade_record.id, tp_client_id)
                if tp_order:
                    sl_tp_orders.append(tp_order)

            logger.info(f"Trade executed successfully: {order_result.get('id')}")
            return {
                'success': True,
                'order_id': order_result.get('id'),
                'trade_id': trade_record.id,
                'symbol': symbol,
                'side': side,
                'size': size,
                'price': current_price,
                'sl_tp_orders': sl_tp_orders
            }
        except Exception as e:
            logger.error(f"Error executing signal: {e}")
            return {
                'success': False,
                'reason': str(e),
                'signal': signal
            }
    
    async def _record_trade(self, signal: Dict[str, Any], order_result: Dict[str, Any], user_id: int, price: float) -> Any:
        """Record trade in database"""
        with db_manager.session_scope() as session:
            from src.db.models import Trade, Signal
            
            # First record the signal
            db_signal = Signal(
                user_id=user_id,
                symbol=signal['symbol'],
                strategy=signal.get('meta', {}).get('strategy', 'unknown'),
                timeframe=signal.get('timeframe', '1m'),
                direction=signal['side'],
                confidence=signal.get('confidence', 0),
                price=price,
                live_price=price,
                meta=str(signal.get('meta', {}))
            )
            session.add(db_signal)
            session.flush()  # Get the signal ID
            
            # Then record the trade
            trade = Trade(
                user_id=user_id,
                signal_id=db_signal.id,
                symbol=signal['symbol'],
                side=signal['side'],
                size=signal['size'],
                entry_price=price,
                sl_price=signal.get('sl'),
                tp_price=signal.get('tp'),
                status='open'
            )
            session.add(trade)
            session.commit()
            
            return trade
    
    async def _set_stop_loss(
        self,
        symbol: str,
        size: float,
        stop_price: float,
        trade_id: int,
        client_id: str,
    ) -> Dict[str, Any]:
        """Set a stop-loss order.

        For spot trading Binance supports stop-loss limit orders. We supply a
        ``clientOrderId`` to preserve idempotency across restarts and specify
        both the stop price and the limit price slightly below the stop.
        """
        try:
            params = {
                'stopPrice': stop_price,
                'clientOrderId': client_id
            }
            # Price for stop-loss-limit orders must be below the stop price for sells
            limit_price = stop_price * 0.995
            order = await self.exchange.create_order(
                symbol,
                'stop_loss_limit',
                'sell',
                size,
                limit_price,
                params
            )
            logger.info(f"Stop loss set for trade {trade_id} at {stop_price}")
            return order
        except Exception as e:
            logger.error(f"Error setting stop loss for trade {trade_id}: {e}")
            return {}
    
    async def _set_take_profit(
        self,
        symbol: str,
        size: float,
        take_profit: float,
        trade_id: int,
        client_id: str,
    ) -> Dict[str, Any]:
        """Set a take-profit order.

        A simple limit sell order is placed at the take-profit price with a
        ``clientOrderId`` to support idempotent submission.
        """
        try:
            params = {'clientOrderId': client_id}
            order = await self.exchange.create_limit_order(
                symbol,
                'sell',
                size,
                take_profit,
                params
            )
            logger.info(f"Take profit set for trade {trade_id} at {take_profit}")
            return order
        except Exception as e:
            logger.error(f"Error setting take profit for trade {trade_id}: {e}")
            return {}
    
    async def close_trade(self, trade_id: int, reason: str = "manual") -> bool:
        """Close trade by ID"""
        try:
            with db_manager.session_scope() as session:
                from src.db.models import Trade
                
                trade = session.query(Trade).filter(Trade.id == trade_id).first()
                if not trade:
                    logger.error(f"Trade {trade_id} not found")
                    return False
                
                # Get current price
                current_price = await self.exchange.fetch_current_price(trade.symbol)
                
                # Execute closing order
                if trade.side == 'BUY':
                    order_side = 'sell'
                else:
                    order_side = 'buy'
                
                await self.exchange.create_market_order(trade.symbol, order_side, trade.size)
                
                # Update trade record
                trade.exit_price = current_price
                trade.pnl = (current_price - trade.entry_price) * trade.size * (1 if trade.side == 'BUY' else -1)
                trade.pnl_percent = (trade.pnl / (trade.entry_price * trade.size)) * 100
                trade.status = 'closed'
                trade.closed_at = datetime.utcnow()
                
                session.commit()
                
                logger.info(f"Trade {trade_id} closed at {current_price}, PnL: {trade.pnl:.2f}")
                return True
                
        except Exception as e:
            logger.error(f"Error closing trade {trade_id}: {e}")
            return False
    
    async def fetch_current_price(self, symbol: str) -> float:
        """Fetch current price for a symbol"""
        try:
            ticker = await self.exchange.fetch_ticker(symbol)
            return ticker['last']
        except Exception as e:
            logger.error(f"Error fetching price for {symbol}: {e}")
            raise