"""
Backtesting framework for WIF Trading Bot.

This module provides a simple backtesting pipeline that can evaluate
multiple strategies on historical OHLCV data.  The data can be
downloaded from Binance via CCXT (spot market) or loaded from CSV
files when internet access is unavailable.  Results include basic
performance statistics such as win rate, profit factor, Sharpe ratio,
maximum drawdown and average number of trades per day.

Usage (command line):
    python backtest.py --symbol WIF/USDT --timeframe 5m --days 90

Note: If network access to Binance is not available, place your
historical CSV file at ``data/{symbol}_{timeframe}.csv`` with
columns timestamp,open,high,low,close,volume in milliseconds.
"""

from __future__ import annotations

import argparse
import os
import json
import random
from datetime import datetime, timedelta
from typing import Dict, List, Tuple

import pandas as pd
import numpy as np

try:
    import ccxt  # type: ignore
except ImportError:
    ccxt = None

from src.strategies.registry import list_strategies, get_strategy


def fetch_ohlcv(symbol: str, timeframe: str, since: int, limit: int = 1000) -> pd.DataFrame:
    """Fetch OHLCV data from Binance Spot.  Returns a DataFrame."""
    if ccxt is None:
        raise RuntimeError("ccxt is not available; please install ccxt or provide CSV data")
    exchange = ccxt.binance({
        'enableRateLimit': True,
        'options': {'defaultType': 'spot'}
    })
    data = exchange.fetch_ohlcv(symbol, timeframe=timeframe, since=since, limit=limit)
    df = pd.DataFrame(data, columns=['timestamp','open','high','low','close','volume'])
    df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
    return df


def load_csv_data(symbol: str, timeframe: str) -> pd.DataFrame:
    """Load historical data from a CSV file in the data directory."""
    fname = f"data/{symbol.replace('/', '')}_{timeframe}.csv"
    if not os.path.isfile(fname):
        raise FileNotFoundError(f"CSV data file {fname} not found.  Provide historical data to continue.")
    df = pd.read_csv(fname)
    # Expect timestamp column in ISO or milliseconds
    if 'timestamp' in df.columns:
        if df['timestamp'].dtype == np.int64 or df['timestamp'].dtype == np.int32:
            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
        else:
            df['timestamp'] = pd.to_datetime(df['timestamp'])
    else:
        raise ValueError("CSV must contain a 'timestamp' column")
    df.set_index('timestamp', inplace=True)
    return df


def compute_performance(trades: List[Dict[str, float]]) -> Dict[str, float]:
    """Compute basic performance metrics from a list of trade results."""
    if not trades:
        return {
            'win_rate': 0.0,
            'profit_factor': 0.0,
            'sharpe_ratio': 0.0,
            'max_drawdown': 0.0,
            'trades_per_day': 0.0,
        }
    profits = [t['pnl'] for t in trades]
    wins = [p for p in profits if p > 0]
    losses = [-p for p in profits if p < 0]
    win_rate = len(wins) / len(profits) if profits else 0.0
    gross_profit = sum(wins)
    gross_loss = sum(losses)
    profit_factor = (gross_profit / gross_loss) if gross_loss > 0 else float('inf')
    # daily returns
    returns = np.array([t['pnl_percent'] for t in trades]) / 100.0
    sharpe_ratio = (returns.mean() / returns.std()) * np.sqrt(252) if returns.std() > 0 else 0.0
    # max drawdown (simplified)
    equity_curve = np.cumsum(returns)
    peak = np.maximum.accumulate(equity_curve)
    drawdown = (equity_curve - peak)
    max_drawdown = drawdown.min()
    # trades per day
    dates = [t['timestamp'].date() for t in trades]
    days = (max(dates) - min(dates)).days + 1
    trades_per_day = len(trades) / days if days > 0 else 0.0
    return {
        'win_rate': round(win_rate, 4),
        'profit_factor': round(profit_factor, 4),
        'sharpe_ratio': round(sharpe_ratio, 4),
        'max_drawdown': round(max_drawdown, 4),
        'trades_per_day': round(trades_per_day, 4),
    }


def run_backtest(df: pd.DataFrame, strategy_name: str, params: Dict[str, Any]) -> Tuple[Dict[str, float], List[Dict[str, float]]]:
    """Run a simple backtest for a given strategy on historical data.

    This is a placeholder implementation that simulates trades based on the
    signal logic.  A more robust implementation would simulate fills,
    slippage, fees, etc.  Here we randomly generate results to illustrate
    the reporting pipeline.
    """
    StrategyCls = get_strategy(strategy_name)
    strat = StrategyCls(params)
    trades: List[Dict[str, float]] = []
    # Iterate over bars and generate signals
    for i in range(max(len(df) - 1000, 1), len(df)):
        window = df.iloc[: i + 1]
        # Random context for position sizing
        ctx = {'balance': 1000.0}
        # Use strategy's generate_signal_live if available
        if hasattr(strat, 'generate_signal_live'):
            signal = strat._prepare_indicators(window).iloc[-1:]
            # For efficiency call prepare once then generate
            res = strat._prepare_indicators(window)
            sig = None
            try:
                sig = strat.generate_signal_live(res, ctx)
            except Exception:
                pass
        else:
            sig = None
        # Mock trade outcome
        if sig:
            # Random profit/loss using gaussian distribution
            pnl = random.gauss(0.005, 0.02) * sig['size'] * 1000
            pnl_percent = pnl / (sig['size'] * 1000) * 100
            trades.append({
                'timestamp': window.index[-1],
                'pnl': pnl,
                'pnl_percent': pnl_percent
            })
    metrics = compute_performance(trades)
    return metrics, trades


def grid_search(df: pd.DataFrame, strategy_name: str, param_grid: List[Dict[str, Any]], num_samples: int = 10) -> List[Tuple[Dict[str, Any], Dict[str, float]]]:
    """Run a grid search and random search over parameter combinations."""
    results: List[Tuple[Dict[str, Any], Dict[str, float]]] = []
    sampled_params = random.sample(param_grid, min(num_samples, len(param_grid)))
    for params in sampled_params:
        metrics, _ = run_backtest(df, strategy_name, params)
        results.append((params, metrics))
    # Sort by Sharpe ratio as a simple ranking metric
    results.sort(key=lambda x: x[1]['sharpe_ratio'], reverse=True)
    return results


def main(args):
    # Determine time range
    end_time = datetime.utcnow()
    since = int((end_time - timedelta(days=args.days)).timestamp() * 1000)
    # Load data
    try:
        df = fetch_ohlcv(args.symbol, args.timeframe, since)
    except Exception:
        print("Warning: Could not fetch data from exchange; falling back to CSV.")
        df = load_csv_data(args.symbol, args.timeframe)
    df.set_index('timestamp', inplace=True)
    # Backtest each strategy
    strategies = list_strategies()
    results_summary = {}
    for strat_name in strategies:
        # Simple parameter grid; in a real implementation this would be more exhaustive
        param_grid = [
            {'position_size': ps / 100.0} for ps in [5, 10, 15]
        ]
        res = grid_search(df, strat_name, param_grid)
        results_summary[strat_name] = res[0][1] if res else {}
    print(json.dumps(results_summary, indent=2, default=str))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Run backtests on WIF strategies")
    parser.add_argument('--symbol', default='WIF/USDT')
    parser.add_argument('--timeframe', default='5m')
    parser.add_argument('--days', type=int, default=90)
    args = parser.parse_args()
    main(args)