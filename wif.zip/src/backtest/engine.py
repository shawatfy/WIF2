import pandas as pd
import numpy as np
from typing import Dict, Any, List, Tuple
from datetime import datetime
from src.utils.logger import setup_logger
from src.strategies.registry import StrategyRegistry

logger = setup_logger('backtest')

class BacktestEngine:
    """Backtesting engine for strategy evaluation"""
    
    def __init__(self, initial_balance: float = 1000.0):
        self.initial_balance = initial_balance
        self.commission = 0.001  # 0.1% commission
    
    def run_strategy_on_df(self, strategy_bt_class, df: pd.DataFrame) -> Dict[str, Any]:
        """
        Run backtest on DataFrame
        
        Returns:
            Dict with metrics and trades
        """
        try:
            # Generate signals
            strategy = strategy_bt_class()
            df_with_signals = strategy.generate_signals(df)
            
            # Execute trades based on signals
            trades, equity_curve = self._execute_trades(df_with_signals)
            
            # Calculate metrics
            metrics = self._calculate_metrics(trades, equity_curve)
            
            return {
                'metrics': metrics,
                'trades': trades,
                'equity_curve': equity_curve,
                'df': df_with_signals
            }
            
        except Exception as e:
            logger.error(f"Error in backtest: {e}")
            raise
    
    def _execute_trades(self, df: pd.DataFrame) -> Tuple[List[Dict], pd.Series]:
        """Execute trades based on signals"""
        trades = []
        position = None
        balance = self.initial_balance
        equity_curve = []
        
        for i, row in df.iterrows():
            # Close position if we have exit signal and are in position
            if position and row['signal'] == -1:
                # Close trade
                pnl = (row['close'] - position['entry_price']) * position['size']
                pnl -= pnl * self.commission * 2  # Entry and exit commission
                
                trade = {
                    'entry_time': position['entry_time'],
                    'exit_time': i,
                    'entry_price': position['entry_price'],
                    'exit_price': row['close'],
                    'size': position['size'],
                    'pnl': pnl,
                    'pnl_percent': (pnl / (position['entry_price'] * position['size'])) * 100,
                    'type': 'long'
                }
                trades.append(trade)
                
                balance += pnl
                position = None
            
            # Open position if we have buy signal and no position
            elif not position and row['signal'] == 1:
                position_size = balance * 0.1  # 10% of balance per trade
                position = {
                    'entry_time': i,
                    'entry_price': row['close'],
                    'size': position_size
                }
                balance -= position_size * self.commission  # Entry commission
            
            # Record equity
            if position:
                current_value = balance + (position['size'] * row['close'])
            else:
                current_value = balance
            
            equity_curve.append(current_value)
        
        # Close any open position at the end
        if position and len(df) > 0:
            last_close = df.iloc[-1]['close']
            pnl = (last_close - position['entry_price']) * position['size']
            pnl -= pnl * self.commission * 2
            
            trade = {
                'entry_time': position['entry_time'],
                'exit_time': df.index[-1],
                'entry_price': position['entry_price'],
                'exit_price': last_close,
                'size': position['size'],
                'pnl': pnl,
                'pnl_percent': (pnl / (position['entry_price'] * position['size'])) * 100,
                'type': 'long'
            }
            trades.append(trade)
        
        return trades, pd.Series(equity_curve, index=df.index[:len(equity_curve)])
    
    def _calculate_metrics(self, trades: List[Dict], equity_curve: pd.Series) -> Dict[str, float]:
        """Calculate performance metrics"""
        if not trades:
            return {
                'total_trades': 0,
                'winning_trades': 0,
                'losing_trades': 0,
                'win_rate': 0,
                'total_pnl': 0,
                'sharpe_ratio': 0,
                'max_drawdown': 0,
                'final_balance': self.initial_balance
            }
        
        # Basic trade metrics
        total_trades = len(trades)
        winning_trades = len([t for t in trades if t['pnl'] > 0])
        losing_trades = len([t for t in trades if t['pnl'] < 0])
        win_rate = winning_trades / total_trades if total_trades > 0 else 0
        total_pnl = sum(t['pnl'] for t in trades)
        final_balance = self.initial_balance + total_pnl
        
        # Sharpe ratio (simplified)
        returns = [t['pnl_percent'] / 100 for t in trades]  # Convert to decimal
        if len(returns) > 1:
            sharpe_ratio = np.mean(returns) / np.std(returns) * np.sqrt(252)  # Annualized
        else:
            sharpe_ratio = 0
        
        # Maximum drawdown
        if len(equity_curve) > 0:
            peak = equity_curve.expanding().max()
            drawdown = (equity_curve - peak) / peak
            max_drawdown = drawdown.min()
        else:
            max_drawdown = 0
        
        return {
            'total_trades': total_trades,
            'winning_trades': winning_trades,
            'losing_trades': losing_trades,
            'win_rate': win_rate,
            'total_pnl': total_pnl,
            'sharpe_ratio': sharpe_ratio,
            'max_drawdown': max_drawdown,
            'final_balance': final_balance,
            'return_percent': (final_balance - self.initial_balance) / self.initial_balance * 100
        }

def run_strategy_on_df(strategy_bt_cls, df: pd.DataFrame) -> Dict[str, Any]:
    """Convenience function to run backtest"""
    engine = BacktestEngine()
    return engine.run_strategy_on_df(strategy_bt_cls, df)