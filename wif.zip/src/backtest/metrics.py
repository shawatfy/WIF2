import pandas as pd
import numpy as np
from typing import Dict, Any, List

def calculate_additional_metrics(trades: List[Dict], equity_curve: pd.Series) -> Dict[str, float]:
    """Calculate additional trading metrics"""
    if not trades:
        return {}
    
    # Profit factor
    gross_profit = sum(t['pnl'] for t in trades if t['pnl'] > 0)
    gross_loss = abs(sum(t['pnl'] for t in trades if t['pnl'] < 0))
    profit_factor = gross_profit / gross_loss if gross_loss > 0 else float('inf')
    
    # Average trade metrics
    avg_win = np.mean([t['pnl'] for t in trades if t['pnl'] > 0]) if any(t['pnl'] > 0 for t in trades) else 0
    avg_loss = np.mean([t['pnl'] for t in trades if t['pnl'] < 0]) if any(t['pnl'] < 0 for t in trades) else 0
    avg_trade = np.mean([t['pnl'] for t in trades])
    
    # Trade durations
    durations = [(t['exit_time'] - t['entry_time']).total_seconds() / 3600 for t in trades]  # in hours
    avg_duration = np.mean(durations) if durations else 0
    
    # Recovery factor (total return / max drawdown)
    total_return = equity_curve.iloc[-1] - equity_curve.iloc[0] if len(equity_curve) > 0 else 0
    peak = equity_curve.expanding().max()
    drawdown = (equity_curve - peak) / peak
    max_drawdown = abs(drawdown.min()) if len(drawdown) > 0 else 0
    recovery_factor = total_return / max_drawdown if max_drawdown > 0 else float('inf')
    
    return {
        'profit_factor': profit_factor,
        'avg_winning_trade': avg_win,
        'avg_losing_trade': avg_loss,
        'avg_trade': avg_trade,
        'avg_trade_duration_hours': avg_duration,
        'recovery_factor': recovery_factor,
        'gross_profit': gross_profit,
        'gross_loss': gross_loss
    }