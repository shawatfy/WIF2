import argparse
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import asyncio
import sys
import os

# Add src to path
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from src.strategies.registry import StrategyRegistry
from src.backtest.engine import BacktestEngine
from src.backtest.metrics import calculate_additional_metrics
from src.utils.logger import setup_logger

logger = setup_logger('backtest_runner')

def generate_sample_data(symbol: str, timeframe: str, days: int = 3) -> pd.DataFrame:
    """Generate more realistic sample OHLCV data for testing"""
    periods = days * 24 * 60  # Assuming 1m data
    
    # Create date range
    end_date = datetime.now()
    start_date = end_date - timedelta(days=days)
    dates = pd.date_range(start=start_date, end=end_date, periods=periods)
    
    # Generate more realistic price data with trends and volatility
    np.random.seed(42)
    
    # Create base price with some trends
    base_price = 2.0
    trend = np.linspace(0, 0.5, periods)  # Upward trend
    noise = np.random.normal(0, 0.02, periods)
    
    prices = base_price * (1 + trend + noise.cumsum() / 100)
    
    # Create OHLC data with proper relationships
    df = pd.DataFrame(index=dates)
    df['close'] = prices
    
    # Generate OHLC that makes sense
    df['open'] = df['close'].shift(1).fillna(df['close'])
    df['high'] = df[['open', 'close']].max(axis=1) + np.random.uniform(0, 0.02, periods)
    df['low'] = df[['open', 'close']].min(axis=1) - np.random.uniform(0, 0.02, periods)
    df['volume'] = np.random.uniform(1000, 10000, periods)
    
    # Ensure high >= low and high >= open, high >= close, low <= open, low <= close
    df['high'] = df[['high', 'open', 'close']].max(axis=1)
    df['low'] = df[['low', 'open', 'close']].min(axis=1)
    
    return df

def load_data_from_csv(symbol: str, timeframe: str) -> pd.DataFrame:
    """Load data from CSV file"""
    filename = f"WIF_{timeframe}_sample.csv"
    filepath = os.path.join(os.path.dirname(__file__), 'data', filename)
    
    if os.path.exists(filepath):
        try:
            df = pd.read_csv(filepath)
            if 'timestamp' in df.columns:
                df['timestamp'] = pd.to_datetime(df['timestamp'])
                df.set_index('timestamp', inplace=True)
            return df
        except Exception as e:
            logger.warning(f"Error loading CSV {filepath}: {e}")
    
    logger.info(f"Generating sample data for {symbol} {timeframe}")
    return generate_sample_data(symbol, timeframe)

async def run_backtest_pro(symbols: list, timeframes: list, days: int = 3, output_dir: str = 'artifacts'):
    """Run professional backtest across multiple symbols and timeframes"""
    os.makedirs(output_dir, exist_ok=True)
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M")
    results = []
    
    strategies = StrategyRegistry.list_strategies()
    
    for symbol in symbols:
        for timeframe in timeframes:
            for strategy_name in strategies:
                try:
                    logger.info(f"Backtesting {strategy_name} on {symbol} {timeframe}")
                    
                    # Load or generate data
                    df = load_data_from_csv(symbol, timeframe)
                    if df is None or df.empty:
                        logger.warning(f"No data for {symbol} {timeframe}, skipping")
                        continue
                    
                    # Get strategy class
                    strategy_class = StrategyRegistry._bt_strategies[strategy_name]
                    
                    # Run backtest
                    engine = BacktestEngine()
                    result = engine.run_strategy_on_df(strategy_class, df)
                    
                    # Add additional metrics only if there are trades
                    if result['trades']:
                        additional_metrics = calculate_additional_metrics(
                            result['trades'], 
                            result['equity_curve']
                        )
                    else:
                        additional_metrics = {
                            'profit_factor': 0,
                            'avg_winning_trade': 0,
                            'avg_losing_trade': 0,
                            'avg_trade': 0,
                            'avg_trade_duration_hours': 0,
                            'recovery_factor': 0,
                            'gross_profit': 0,
                            'gross_loss': 0
                        }
                    
                    # Combine results
                    combined_metrics = {**result['metrics'], **additional_metrics}
                    combined_metrics.update({
                        'symbol': symbol,
                        'timeframe': timeframe,
                        'strategy': strategy_name,
                        'data_points': len(df),
                        'period_days': days
                    })
                    
                    results.append(combined_metrics)
                    
                    logger.info(f"Completed {strategy_name} on {symbol} {timeframe}: "
                               f"Trades: {combined_metrics['total_trades']}, "
                               f"Win Rate: {combined_metrics['win_rate']:.2%}, "
                               f"PnL: {combined_metrics['total_pnl']:.2f}")
                    
                except Exception as e:
                    logger.error(f"Error backtesting {strategy_name} on {symbol} {timeframe}: {e}")
                    import traceback
                    traceback.print_exc()
    
    # Save results
    if results:
        df_results = pd.DataFrame(results)
        
        # Ensure all required columns exist
        required_columns = ['win_rate', 'total_pnl', 'sharpe_ratio', 'max_drawdown', 'profit_factor']
        for col in required_columns:
            if col not in df_results.columns:
                df_results[col] = 0
        
        # Save detailed results
        detailed_file = os.path.join(output_dir, f'backtest_per_timeframe_{timestamp}.csv')
        df_results.to_csv(detailed_file, index=False)
        
        # Save aggregate results
        try:
            aggregate = df_results.groupby('strategy').agg({
                'win_rate': 'mean',
                'total_pnl': 'sum',
                'sharpe_ratio': 'mean',
                'max_drawdown': 'mean',
                'profit_factor': 'mean'
            }).reset_index()
            
            aggregate_file = os.path.join(output_dir, f'backtest_aggregate_{timestamp}.csv')
            aggregate.to_csv(aggregate_file, index=False)
            
            logger.info(f"Backtest results saved to {detailed_file} and {aggregate_file}")
            
            # Print summary
            print("\n=== BACKTEST SUMMARY ===")
            print(aggregate.to_string(index=False, float_format='%.4f'))
            
        except Exception as e:
            logger.error(f"Error creating aggregate results: {e}")
            print("\n=== DETAILED RESULTS ===")
            print(df_results[['strategy', 'symbol', 'timeframe', 'total_trades', 'win_rate', 'total_pnl']].to_string(index=False))
    
    else:
        logger.warning("No results generated from backtest")
        print("No results generated. Check strategy parameters and data.")
    
    return results

def main():
    parser = argparse.ArgumentParser(description='Run professional backtest')
    parser.add_argument('--symbols', type=str, required=True, 
                       help='Comma-separated list of symbols (e.g., WIF/USDT,PEPE/USDT)')
    parser.add_argument('--timeframes', type=str, required=True,
                       help='Comma-separated list of timeframes (e.g., 1m,5m,15m)')
    parser.add_argument('--days', type=int, default=3,
                       help='Number of days of data to use')
    parser.add_argument('--out', type=str, default='artifacts',
                       help='Output directory for results')
    
    args = parser.parse_args()
    
    symbols = [s.strip() for s in args.symbols.split(',')]
    timeframes = [tf.strip() for tf in args.timeframes.split(',')]
    
    asyncio.run(run_backtest_pro(symbols, timeframes, args.days, args.out))

if __name__ == '__main__':
    main()