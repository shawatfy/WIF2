import pandas as pd
from typing import Dict, Any, Optional
from .base_live import BaseStrategyLive
from src.strategies.registry import register_strategy


@register_strategy
class DonchianATRLive(BaseStrategyLive):
    """Donchian channel breakout strategy with ATR trailing stop (enhanced for Send-All mode)."""

    def __init__(self, params: Optional[Dict[str, Any]] = None):
        params = params or {
            "donchian_period": 30,
            "atr_period": 10,
            "atr_multiplier": 3,
            "position_size": 0.1,
            "tp_atr_multiple": 2,
        }
        super().__init__("DonchianATR", params)

    def _prepare_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        """Ensure indicators are always computed safely."""
        df = df.copy()
        if not all(col in df.columns for col in ["high", "low", "close"]):
            return df  # invalid data

        n = self.params["donchian_period"]
        df["donchian_high"] = df["high"].rolling(window=n, min_periods=n).max()
        df["donchian_low"] = df["low"].rolling(window=n, min_periods=n).min()
        df["atr"] = self.calculate_atr(df, self.params["atr_period"])
        return df

    async def generate_signal_live(self, df: pd.DataFrame, ctx: Dict[str, Any]) -> Dict:
        """Generate live signal or analysis output (never None)."""
        if df.empty or len(df) < max(self.params["donchian_period"], self.params["atr_period"]) + 1:
            return {"side": "NONE", "confidence": 0, "meta": {"reason": "insufficient data"}}

        df = self._prepare_indicators(df)
        latest = df.iloc[-1]

        # safety check
        if any(col not in latest or pd.isna(latest[col]) for col in ["donchian_high", "atr", "close"]):
            return {"side": "NONE", "confidence": 0, "meta": {"reason": "incomplete indicators"}}

        prev_close = df["close"].iloc[-2]
        donchian_high = latest["donchian_high"]
        atr = latest["atr"]
        price = latest["close"]

        # breakout detection
        if price > donchian_high and prev_close <= donchian_high:
            sl_price = price - self.params["atr_multiplier"] * atr
            tp_price = price + self.params["tp_atr_multiple"] * atr
            strength = (price - donchian_high) / atr if atr > 0 else 0
            confidence = float(min(1.0, max(0.0, strength)))

            return {
                "side": "BUY",
                "size": self.params["position_size"],
                "sl": float(sl_price),
                "tp": float(tp_price),
                "confidence": confidence,
                "meta": {
                    "signal_type": "ENTRY",
                    "donchian_high": float(donchian_high),
                    "atr": float(atr),
                    "price": float(price),
                    "strategy": self.name,
                    "comment": "Donchian breakout above channel high",
                    "size": self.params["position_size"],
                    "sl": float(sl_price),
                    "tp": float(tp_price),
                },
            }

        # 📊 No signal — analysis mode
        upper_buffer = float(donchian_high)
        distance = (upper_buffer - price) / upper_buffer if upper_buffer != 0 else 0
        return {
            "side": "NONE",
            "confidence": 0,
            "meta": {
                "signal_type": "ANALYSIS",
                "comment": "No breakout yet; price below Donchian high",
                "price": float(price),
                "donchian_high": float(donchian_high),
                "atr": float(atr),
                "distance_to_breakout_%": round(distance * 100, 3),
                "strategy": self.name,
            },
        }