import pandas as pd
import numpy as np
from typing import Dict, Any, Optional
from .base_live import BaseStrategyLive
from src.strategies.registry import register_strategy

@register_strategy
class TrendSurferStrategy:
    ...

class TrendSurferLive(BaseStrategyLive):
    """Trend Surfer strategy for live trading - FIXED VERSION"""
    
    def __init__(self, params=None):
        params = params or {
            'ema_fast': 9,
            'ema_slow': 21,
            'stoch_rsi_period': 14,
            'stoch_rsi_smooth': 3,
            'stoch_oversold': 20,
            'position_size': 0.1,
            'sl_percent': 0.015,
            'tp_percent': 0.025
        }
        super().__init__('TrendSurfer', params)
    
    def _prepare_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        """Prepare data with indicators - FIXED VERSION"""
        df = df.copy()
        
        # EMAs
        df['ema_fast'] = self.calculate_ema(df, self.params['ema_fast'])
        df['ema_slow'] = self.calculate_ema(df, self.params['ema_slow'])
        
        # Stochastic RSI
        df['stoch_rsi'] = self._calculate_stoch_rsi(
            df, 
            self.params['stoch_rsi_period'], 
            self.params['stoch_rsi_smooth']
        )
        
        return df
    
    def _calculate_stoch_rsi(self, df: pd.DataFrame, period: int = 14, smooth: int = 3) -> pd.Series:
        """Calculate Stochastic RSI - ADDED METHOD"""
        rsi = self.calculate_rsi(df, period)
        stoch_rsi = (rsi - rsi.rolling(period).min()) / (rsi.rolling(period).max() - rsi.rolling(period).min())
        return stoch_rsi.rolling(smooth).mean()
    
    async def generate_signal_live(self, df: pd.DataFrame, ctx: Dict[str, Any]) -> Optional[Dict]:
        """Generate live trading signal - FIXED VERSION"""
        try:
            df_prepared = await self.prepare_async(df)
            
            if df_prepared.empty or len(df_prepared) < 2:
                return None
            
            latest = df_prepared.iloc[-1]
            prev = df_prepared.iloc[-2]
            
            # Check if required indicators are calculated
            if 'ema_fast' not in latest or 'ema_slow' not in latest or 'stoch_rsi' not in latest:
                return None
            
            # Strategy conditions
            ema_aligned = latest['ema_fast'] > latest['ema_slow']
            stoch_oversold = latest['stoch_rsi'] < (self.params['stoch_oversold'] / 100)
            stoch_rising = latest['stoch_rsi'] > prev['stoch_rsi']
            
            if ema_aligned and stoch_oversold and stoch_rising:
                current_price = ctx.get('current_price', latest['close'])
                
                return {
                    "side": "BUY",
                    "size": self.params['position_size'],
                    "sl": current_price * (1 - self.params['sl_percent']),
                    "tp": current_price * (1 + self.params['tp_percent']),
                    "confidence": 0.75,
                    "meta": {
                        "ema_fast": float(latest['ema_fast']),
                        "ema_slow": float(latest['ema_slow']),
                        "stoch_rsi": float(latest['stoch_rsi']),
                        "strategy": self.name
                    }
                }
            
            return None
            
        except Exception as e:
            logger.error(f"Error in TrendSurfer signal generation: {e}")
            return None