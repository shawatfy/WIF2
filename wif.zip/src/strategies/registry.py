"""
Strategy Registry for WIF Trading Bot 3.0
-----------------------------------------
Auto-discovers and registers all strategy classes at import time.
Compatible with both new and legacy access patterns.
"""

from typing import Dict, Type
import pkgutil
import importlib
import src.strategies

# ======================================
# ✅ Global Registry
# ======================================
STRATEGY_REGISTRY: Dict[str, Type] = {}


def register_strategy(cls):
    """Decorator to register strategy class globally."""
    STRATEGY_REGISTRY[cls.__name__] = cls
    print(f"✅ Strategy registered: {cls.__name__}")
    return cls


def get_strategy(name: str):
    """Retrieve a strategy class by name."""
    return STRATEGY_REGISTRY.get(name)


def list_strategies():
    """List all registered strategy names."""
    return list(STRATEGY_REGISTRY.keys())


# ======================================
# 🔄 Auto-discover and import all strategies
# ======================================
def _auto_discover_strategies():
    for _, module_name, _ in pkgutil.iter_modules(src.strategies.__path__):
        if module_name not in ("registry", "__init__"):
            importlib.import_module(f"src.strategies.{module_name}")


_auto_discover_strategies()


# ======================================
# 🧩 Legacy compatibility
# ======================================
class StrategyRegistry:
    @staticmethod
    def get(name: str):
        return get_strategy(name)

    @staticmethod
    def list():
        return list_strategies()


# ======================================
# 🧠 Debug info
# ======================================
if not STRATEGY_REGISTRY:
    print("⚠️ No strategies registered. Check your strategy files.")
else:
    print(f"✅ Loaded strategies: {', '.join(STRATEGY_REGISTRY.keys())}")