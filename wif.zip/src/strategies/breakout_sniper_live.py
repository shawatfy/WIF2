import pandas as pd
import numpy as np
from typing import Dict, Any, Optional
from .base_live import BaseStrategyLive
from src.strategies.registry import register_strategy

@register_strategy
class breakoutSniperStrategy:
    ...


class BreakoutSniperLive(BaseStrategyLive):
    """Breakout Sniper strategy for live trading - FIXED VERSION"""
    
    def __init__(self, params=None):
        params = params or {
            'swing_period': 20,
            'volume_factor': 1.5,
            'rsi_neutral_min': 40,
            'rsi_neutral_max': 60,
            'position_size': 0.1,
            'sl_percent': 0.01,
            'tp_percent': 0.02
        }
        super().__init__('BreakoutSniper', params)
    
    def _prepare_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        """Prepare data with indicators - FIXED VERSION"""
        df = df.copy()
        
        # Swing highs/lows
        df['swing_high'] = df['high'].rolling(window=self.params['swing_period']).max()
        df['swing_low'] = df['low'].rolling(window=self.params['swing_period']).min()
        
        # Volume analysis
        df['volume_ma'] = df['volume'].rolling(window=20).mean()
        df['volume_ratio'] = df['volume'] / df['volume_ma']
        
        # RSI filter
        df['rsi'] = self.calculate_rsi(df, 14)
        
        return df
    
    async def generate_signal_live(self, df: pd.DataFrame, ctx: Dict[str, Any]) -> Optional[Dict]:
        """Generate live trading signal - FIXED VERSION"""
        try:
            df_prepared = await self.prepare_async(df)
            
            if df_prepared.empty or len(df_prepared) < 2:
                return None
            
            latest = df_prepared.iloc[-1]
            prev = df_prepared.iloc[-2]
            
            # Check if required indicators are calculated
            if 'swing_high' not in prev or 'volume_ratio' not in latest or 'rsi' not in latest:
                return None
            
            # Strategy conditions
            breakout_condition = latest['close'] > prev['swing_high']
            volume_condition = latest['volume_ratio'] > self.params['volume_factor']
            rsi_condition = (
                self.params['rsi_neutral_min'] < latest['rsi'] < self.params['rsi_neutral_max']
            )
            
            if breakout_condition and volume_condition and rsi_condition:
                current_price = ctx.get('current_price', latest['close'])
                
                return {
                    "side": "BUY",
                    "size": self.params['position_size'],
                    "sl": current_price * (1 - self.params['sl_percent']),
                    "tp": current_price * (1 + self.params['tp_percent']),
                    "confidence": 0.8,
                    "meta": {
                        "swing_high": float(prev['swing_high']),
                        "volume_ratio": float(latest['volume_ratio']),
                        "rsi": float(latest['rsi']),
                        "strategy": self.name
                    }
                }
            
            return None
            
        except Exception as e:
            logger.error(f"Error in BreakoutSniper signal generation: {e}")
            return None