"""
VWAP Z-Score mean-reversion strategy for live spot trading.

Now supports full analysis output even when no signal is generated,
for Send-All mode in Telegram.
"""

import pandas as pd
import numpy as np
from typing import Dict, Any, Optional
from .base_live import BaseStrategyLive
from src.strategies.registry import register_strategy


@register_strategy
class VWAPZScoreLive(BaseStrategyLive):
    """VWAP Z-Score Mean Reversion strategy (enhanced for Send-All mode)."""

    def __init__(self, params: Optional[Dict[str, Any]] = None):
        params = params or {
            "z_window": 30,
            "z_threshold": -2.0,
            "rsi_period": 14,
            "rsi_threshold": 40,
            "position_size": 0.1,
            "sl_buffer": 0.99,  # 1% below current price
        }
        super().__init__("VWAPZScore", params)

    def _prepare_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        df = df.copy()
        if df.empty or not all(c in df.columns for c in ["high", "low", "close", "volume"]):
            return df

        typical_price = (df["high"] + df["low"] + df["close"]) / 3
        df["vwap"] = (typical_price * df["volume"]).cumsum() / df["volume"].cumsum()

        window = self.params["z_window"]
        diff = df["close"] - df["vwap"]
        rolling_mean = diff.rolling(window=window, min_periods=window).mean()
        rolling_std = diff.rolling(window=window, min_periods=window).std()
        df["zscore"] = (diff - rolling_mean) / rolling_std
        df["rsi"] = self.calculate_rsi(df, self.params["rsi_period"])
        return df

    async def generate_signal_live(self, df: pd.DataFrame, ctx: Dict[str, Any]) -> Dict:
        """Always return a dict: BUY or analysis-only output."""
        if df.empty or len(df) < max(self.params["z_window"], self.params["rsi_period"]) + 1:
            return {"side": "NONE", "confidence": 0, "meta": {"reason": "insufficient data"}}

        df = self._prepare_indicators(df)
        latest = df.iloc[-1]
        prev = df.iloc[-2]

        if any(c not in latest for c in ["zscore", "rsi", "vwap"]):
            return {"side": "NONE", "confidence": 0, "meta": {"reason": "missing indicators"}}

        zscore = latest["zscore"]
        rsi = latest["rsi"]
        price = latest["close"]
        vwap = latest["vwap"]

        # Long entry condition
        if zscore <= self.params["z_threshold"] and rsi < self.params["rsi_threshold"] and rsi > prev["rsi"]:
            sl_price = price * self.params["sl_buffer"]
            tp_price = vwap
            z_excess = abs(zscore - self.params["z_threshold"])
            confidence = float(min(1.0, max(0.0, z_excess / 2)))
            return {
                "side": "BUY",
                "size": self.params["position_size"],
                "sl": float(sl_price),
                "tp": float(tp_price),
                "confidence": confidence,
                "meta": {
                    "zscore": float(zscore),
                    "vwap": float(vwap),
                    "rsi": float(rsi),
                    "strategy": self.name,
                    "signal_type": "ENTRY",
                    "comment": "VWAP mean-reversion opportunity",
                    "size": self.params["position_size"],
                    "sl": float(sl_price),
                    "tp": float(tp_price),
                },
            }

        # 📊 No trade, but send analysis summary (for "Send All Signals")
        return {
            "side": "NONE",
            "confidence": 0,
            "meta": {
                "zscore": float(zscore),
                "vwap": float(vwap),
                "rsi": float(rsi),
                "strategy": self.name,
                "signal_type": "ANALYSIS",
                "comment": "No entry condition met; monitoring mean reversion setup",
                "price": float(price),
                "vwap_deviation": float(zscore),
            },
        }