import pandas as pd
import numpy as np
from typing import Dict, Any, Optional
from .base_live import BaseStrategyLive
from src.strategies.registry import register_strategy

@register_strategy
class DipHunterStrategy:
    ...
class DipHunterLive(BaseStrategyLive):
    """Dip Hunter strategy for live trading - FIXED VERSION"""
    
    def __init__(self, params=None):
        params = params or {
            'rsi_period': 14,
            'rsi_oversold': 30,
            'rsi_exit': 50,
            'vwap_deviation': -0.02,
            'tp_percent': 0.03,
            'sl_percent': 0.02,
            'position_size': 0.1
        }
        super().__init__('DipHunter', params)
    
    def _prepare_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        """Prepare data with indicators - FIXED VERSION"""
        df = df.copy()
        
        # Calculate RSI
        df['rsi'] = self.calculate_rsi(df, self.params['rsi_period'])
        
        # Calculate VWAP
        df['vwap'] = self._calculate_vwap(df)
        df['price_vwap_ratio'] = df['close'] / df['vwap'] - 1
        
        return df
    
    def _calculate_vwap(self, df: pd.DataFrame) -> pd.Series:
        """Calculate VWAP indicator - ADDED METHOD"""
        typical_price = (df['high'] + df['low'] + df['close']) / 3
        volume = df['volume']
        vwap = (typical_price * volume).cumsum() / volume.cumsum()
        return vwap
    
    async def generate_signal_live(self, df: pd.DataFrame, ctx: Dict[str, Any]) -> Optional[Dict]:
        """Generate live trading signal - FIXED VERSION"""
        try:
            # Prepare data in thread to avoid blocking
            df_prepared = await self.prepare_async(df)
            
            if df_prepared.empty or len(df_prepared) < 2:
                return None
            
            latest = df_prepared.iloc[-1]
            prev = df_prepared.iloc[-2]
            
            # Check if required indicators are calculated
            if 'rsi' not in latest or 'price_vwap_ratio' not in latest:
                return None
            
            # Buy signal conditions
            rsi_oversold = latest['rsi'] < self.params['rsi_oversold']
            price_below_vwap = latest['price_vwap_ratio'] < self.params['vwap_deviation']
            rsi_rising = latest['rsi'] > prev['rsi']
            
            if rsi_oversold and price_below_vwap and rsi_rising:
                current_price = ctx.get('current_price', latest['close'])
                
                return {
                    "side": "BUY",
                    "size": self.params['position_size'],
                    "sl": current_price * (1 - self.params['sl_percent']),
                    "tp": current_price * (1 + self.params['tp_percent']),
                    "confidence": min(0.9, (self.params['rsi_oversold'] - latest['rsi']) / self.params['rsi_oversold']),
                    "meta": {
                        "rsi": float(latest['rsi']),
                        "vwap_ratio": float(latest['price_vwap_ratio']),
                        "strategy": self.name
                    }
                }
            
            return None
            
        except Exception as e:
            logger.error(f"Error in DipHunter signal generation: {e}")
            return None