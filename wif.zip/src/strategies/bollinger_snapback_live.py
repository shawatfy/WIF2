"""
Improved Bollinger Snapback for live spot trading.

Now returns analysis output even when no entry signal is found
(for Send-All mode). Confidence reflects deviation and RSI recovery.
"""

import pandas as pd
import numpy as np
from typing import Dict, Any, Optional
from .base_live import BaseStrategyLive
from src.strategies.registry import register_strategy


@register_strategy
class BollingerSnapbackLive(BaseStrategyLive):
    """Bollinger Snapback mean-reversion strategy (spot, long-only)."""

    def __init__(self, params: Optional[Dict[str, Any]] = None):
        params = params or {
            "sma_period": 18,
            "std_multiplier": 2,
            "rsi_period": 10,
            "rsi_threshold": 35,
            "entry_tolerance": 0.003,  # 0.3% tolerance above lower band
            "position_size": 0.1,
            "sl_buffer": 0.985,        # 1.5% below lower band
        }
        super().__init__("BollingerSnapback", params)

    def _prepare_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        df = df.copy()
        n = self.params["sma_period"]
        k = self.params["std_multiplier"]
        df["sma"] = df["close"].rolling(window=n, min_periods=n).mean()
        df["std"] = df["close"].rolling(window=n, min_periods=n).std()
        df["upper_band"] = df["sma"] + k * df["std"]
        df["lower_band"] = df["sma"] - k * df["std"]
        df["rsi"] = self.calculate_rsi(df, self.params["rsi_period"])
        return df

    async def generate_signal_live(self, df: pd.DataFrame, ctx: Dict[str, Any]) -> Dict:
        """Always return a dict (signal or analysis)."""
        if df.empty or len(df) < max(self.params["sma_period"], self.params["rsi_period"]) + 1:
            return {"side": "NONE", "confidence": 0, "meta": {"reason": "insufficient data"}}

        df = self._prepare_indicators(df)
        latest = df.iloc[-1]
        prev = df.iloc[-2]

        # safety checks
        for col in ["sma", "lower_band", "rsi"]:
            if col not in latest or pd.isna(latest[col]):
                return {"side": "NONE", "confidence": 0, "meta": {"reason": f"missing {col}"}}

        price = latest["close"]
        lower = latest["lower_band"]
        sma = latest["sma"]
        rsi = latest["rsi"]
        prev_rsi = prev["rsi"]

        near_lower = price <= lower * (1 + self.params["entry_tolerance"])
        rsi_rising = rsi > prev_rsi and rsi < self.params["rsi_threshold"]

        if near_lower and rsi_rising:
            sl_price = lower * self.params["sl_buffer"]
            tp_price = sma
            deviation = max(0, (lower - price) / lower)
            slope = max(0, (rsi - prev_rsi) / max(1, prev_rsi))
            confidence = float(min(1.0, deviation * 4 + slope))
            return {
                "side": "BUY",
                "size": self.params["position_size"],
                "sl": float(sl_price),
                "tp": float(tp_price),
                "confidence": max(confidence, 0.05),
                "meta": {
                    "signal_type": "ENTRY",
                    "rsi": float(rsi),
                    "rsi_prev": float(prev_rsi),
                    "sma": float(sma),
                    "lower_band": float(lower),
                    "price": float(price),
                    "deviation": float(deviation),
                    "strategy": self.name,
                    "comment": "RSI recovery near lower band",
                    "size": self.params["position_size"],
                    "sl": float(sl_price),
                    "tp": float(tp_price),
                },
            }

        # 📊 No signal — return analysis summary
        deviation = (lower - price) / lower if lower else 0
        return {
            "side": "NONE",
            "confidence": 0,
            "meta": {
                "signal_type": "ANALYSIS",
                "comment": "No oversold recovery; monitoring mean reversion zone",
                "rsi": float(rsi),
                "sma": float(sma),
                "lower_band": float(lower),
                "price": float(price),
                "deviation": float(deviation),
                "strategy": self.name,
            },
        }