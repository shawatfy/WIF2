import pandas as pd
import numpy as np
import asyncio
from abc import ABC, abstractmethod
from typing import Dict, Any, Optional

# Add logger
from src.utils.logger import setup_logger
logger = setup_logger('strategies')

class BaseStrategyLive(ABC):
    """Base class for live trading strategies (asynchronous) - FIXED VERSION"""
    
    def __init__(self, name: str, params: Dict[str, Any] = None):
        self.name = name
        self.params = params or {}
        
    def prepare(self, df: pd.DataFrame) -> pd.DataFrame:
        """Prepare data with indicators (sync, can be run in thread)"""
        return self._prepare_indicators(df)
    
    @abstractmethod
    def _prepare_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        """Prepare indicators - to be implemented by subclasses"""
        pass
    
    @abstractmethod
    async def generate_signal_live(self, df: pd.DataFrame, ctx: Dict[str, Any]) -> Optional[Dict]:
        """
        Generate live trading signal
        
        Returns:
            Dict with keys: side, size, sl, tp, confidence, meta
            or None for no signal
        """
        pass
    
    async def prepare_async(self, df: pd.DataFrame) -> pd.DataFrame:
        """Async wrapper for prepare method"""
        return await asyncio.to_thread(self.prepare, df)
    
    def calculate_rsi(self, df: pd.DataFrame, period: int = 14) -> pd.Series:
        """Calculate RSI indicator"""
        delta = df['close'].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs))
        return rsi
    
    def calculate_ema(self, df: pd.DataFrame, period: int) -> pd.Series:
        """Calculate EMA indicator"""
        return df['close'].ewm(span=period, adjust=False).mean()
    
    def calculate_atr(self, df: pd.DataFrame, period: int = 14) -> pd.Series:
        """Calculate ATR indicator"""
        high_low = df['high'] - df['low']
        high_close = np.abs(df['high'] - df['close'].shift())
        low_close = np.abs(df['low'] - df['close'].shift())
        true_range = np.maximum(high_low, np.maximum(high_close, low_close))
        atr = true_range.rolling(window=period).mean()
        return atr