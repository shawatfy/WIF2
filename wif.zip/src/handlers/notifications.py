from typing import Dict, Any
from src.utils.logger import setup_logger

logger = setup_logger('notifications')

class NotificationManager:
    """Manage trading notifications"""
    
    def __init__(self, bot):
        self.bot = bot
    
    async def send_signal_alert(self, chat_id: int, signal: Dict[str, Any]):
        """Send signal alert"""
        try:
            text = f"""
🎯 *New Trading Signal*

*Strategy:* {signal.get('strategy', 'Unknown')}
*Symbol:* {signal.get('symbol', 'Unknown')}  
*Action:* {signal.get('side', 'FLAT')}
*Confidence:* {signal.get('confidence', 0):.2f}
*Size:* {signal.get('size', 0)}

*Meta:*
{self._format_meta(signal.get('meta', {}))}

text
            """
            
            await self.bot.send_message(chat_id, text, parse_mode='Markdown')
            
        except Exception as e:
            logger.error(f"Error sending signal alert: {e}")
    
    async def send_execution_confirmation(self, chat_id: int, execution: Dict[str, Any]):
        """Send execution confirmation"""
        try:
            if execution['success']:
                text = f"""
✅ *Order Executed*

*Symbol:* {execution['symbol']}
*Side:* {execution['side']}
*Size:* {execution['size']}
*Price:* ${execution['price']:.6f}
*Order ID:* `{execution['order_id']}`
                """
            else:
                text = f"""
❌ *Order Failed*

*Reason:* {execution['reason']}
*Symbol:* {execution['signal']['symbol']}
*Side:* {execution['signal']['side']}
                """
            
            await self.bot.send_message(chat_id, text, parse_mode='Markdown')
            
        except Exception as e:
            logger.error(f"Error sending execution confirmation: {e}")
    
    async def send_error_alert(self, chat_id: int, error: str, context: str = ""):
        """Send error alert"""
        try:
            text = f"""
🚨 *System Error*

*Context:* {context}
*Error:* {error}

Please check the logs for details.
            """
            
            await self.bot.send_message(chat_id, text, parse_mode='Markdown')
            
        except Exception as e:
            logger.error(f"Error sending error alert: {e}")
    
    def _format_meta(self, meta: Dict[str, Any]) -> str:
        """Format meta data for display"""
        lines = []
        for key, value in meta.items():
            if isinstance(value, float):
                lines.append(f"{key}: {value:.4f}")
            else:
                lines.append(f"{key}: {value}")
        
        return "\n".join(lines)