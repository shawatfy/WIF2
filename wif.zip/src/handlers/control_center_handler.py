from aiogram import Router, F
from aiogram.filters import Command, CommandObject
from aiogram.types import Message, CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.utils.keyboard import InlineKeyboardBuilder
from typing import Dict, Any, Optional, List
import asyncio

from src.utils.logger import setup_logger
from src.services.signal_engine import SignalEngine
from src.services.exec_engine import ExecutionEngine
from src.strategies.registry import list_strategies
from src.utils.config import Config

logger = setup_logger('telegram_handler')

# ==================== FSM STATES FOR WIZARD FLOW ====================
class AutoTradeWizard(StatesGroup):
    select_symbols = State()
    select_strategy = State()
    select_risk = State()
    confirmation = State()

class SignalModeWizard(StatesGroup):
    select_symbols = State()
    select_frequency = State()
    select_confidence = State()
    select_strategy = State()
    confirmation = State()

class ControlCenterHandler:
    """Telegram bot with Step-by-Step Wizard Flow"""
    
    def __init__(self, bot, signal_engine: SignalEngine, exec_engine: ExecutionEngine):
        self.bot = bot
        self.signal_engine = signal_engine
        self.exec_engine = exec_engine
        self.router = Router()
        self.user_sessions = {}
        
        self._register_handlers()

    def _register_handlers(self):
        """Register all handlers"""
        # Command handlers
        self.router.message.register(self.start_command, Command("start"))
        self.router.message.register(self.help_command, Command("help"))
        # Health check command
        self.router.message.register(self.ping_command, Command("ping"))
        
        # Main menu handlers
        self.router.callback_query.register(
            self.handle_main_menu, 
            lambda c: c.data and c.data.startswith("main_")
        )
        
        # Auto Trade Wizard handlers
        self.router.callback_query.register(
            self.handle_auto_wizard,
            lambda c: c.data and c.data.startswith("auto_")
        )
        
        # Signal Mode Wizard handlers
        self.router.callback_query.register(
            self.handle_signal_wizard,
            lambda c: c.data and c.data.startswith("signal_")
        )
        
        # Portfolio & Reports
        self.router.callback_query.register(
            self.handle_other_menus,
            lambda c: c.data and (c.data.startswith("portfolio_") or c.data.startswith("reports_"))
        )

    # ==================== START & MAIN MENU ====================
    async def start_command(self, message: Message):
        """🏁 Start command with main menu"""
        welcome_text = """
🤖 <b>WIF Trading Bot 3.0</b>

🎯 <b>Choose your trading mode:</b>

• <b>Auto Trade</b> - Full automated trading
• <b>Signal Mode</b> - Signal alerts only  
• <b>Portfolio</b> - View positions
• <b>Reports</b> - Performance analytics
        """
        
        keyboard = self._create_main_menu_keyboard()
        await message.answer(welcome_text, reply_markup=keyboard, parse_mode='HTML')

    def _create_main_menu_keyboard(self) -> InlineKeyboardMarkup:
        """Create main menu keyboard"""
        builder = InlineKeyboardBuilder()
        
        builder.row(
            InlineKeyboardButton(text="🤖 Auto Trade", callback_data="main_auto"),
            InlineKeyboardButton(text="📡 Signal Mode", callback_data="main_signal")
        )
        builder.row(
            InlineKeyboardButton(text="💼 Portfolio", callback_data="main_portfolio"),
            InlineKeyboardButton(text="📊 Reports", callback_data="main_reports")
        )
        
        return builder.as_markup()

    async def handle_main_menu(self, callback: CallbackQuery, state: FSMContext):
        """Handle main menu selections"""
        await callback.answer()
        
        action = callback.data.split("_")[1]
        
        if action == "auto":
            # Start Auto Trade Wizard
            await state.set_state(AutoTradeWizard.select_symbols)
            await self._show_auto_symbols_step(callback, state)
            
        elif action == "signal":
            # Start Signal Mode Wizard
            await state.set_state(SignalModeWizard.select_symbols)
            await self._show_signal_symbols_step(callback, state)
            
        elif action == "portfolio":
            await self._show_portfolio_menu(callback)
        elif action == "reports":
            await self._show_reports_menu(callback)

    # ==================== AUTO TRADE WIZARD FLOW ====================
    async def _show_auto_symbols_step(self, callback: CallbackQuery, state: FSMContext):
        """Step 1: Select symbols for Auto Trade"""
        text = """
🤖 <b>Auto Trade Setup - Step 1/3</b>

🔤 <b>Select Trading Symbols</b>

Choose the symbols you want to trade:
        """
        
        # Retrieve currently selected symbols to display toggle state
        data = await state.get_data()
        selected = data.get('auto_symbols', [])
        keyboard = self._create_symbols_keyboard("auto", selected)
        await callback.message.edit_text(text, reply_markup=keyboard, parse_mode='HTML')

    async def _show_auto_strategy_step(self, callback: CallbackQuery, state: FSMContext):
        """Step 2: Select strategy for Auto Trade"""
        # Get selected symbols from state
        data = await state.get_data()
        symbols = data.get('auto_symbols', [])
        
        text = f"""
🤖 <b>Auto Trade Setup - Step 2/3</b>

✅ <b>Selected Symbols:</b> {', '.join(symbols)}

🎯 <b>Select Trading Strategy</b>

Choose your trading algorithm:
        """
        
        # Retrieve selected strategies to display toggle state
        data = await state.get_data()
        selected_strategies = data.get('auto_strategies', [])
        keyboard = self._create_strategy_keyboard("auto", selected_strategies)
        await callback.message.edit_text(text, reply_markup=keyboard, parse_mode='HTML')

    async def _show_auto_risk_step(self, callback: CallbackQuery, state: FSMContext):
        """Step 3: Select risk level for Auto Trade"""
        # Get previous selections
        data = await state.get_data()
        symbols = data.get('auto_symbols', [])
        # Display selected strategies (multiple possible)
        strategies = data.get('auto_strategies', [])
        strategy = ', '.join(strategies) if strategies else 'Not selected'
        
        text = f"""
🤖 <b>Auto Trade Setup - Step 3/3</b>

✅ <b>Symbols:</b> {', '.join(symbols)}
✅ <b>Strategies:</b> {strategy}

⚖️ <b>Select Risk Level</b>

Choose your risk tolerance:
        """
        
        keyboard = self._create_risk_keyboard("auto")
        await callback.message.edit_text(text, reply_markup=keyboard, parse_mode='HTML')

    async def _show_auto_confirmation_step(self, callback: CallbackQuery, state: FSMContext):
        """Final Step: Confirmation for Auto Trade"""
        # Get all selections
        data = await state.get_data()
        symbols = data.get('auto_symbols', [])
        strategies = data.get('auto_strategies', [])
        strategy = ', '.join(strategies) if strategies else 'Not selected'
        risk = data.get('auto_risk', 'Not selected')
        
        risk_display = {
            'low': 'Low (1% per trade)',
            'medium': 'Medium (2% per trade)',
            'high': 'High (3% per trade)'
        }.get(risk, risk)
        
        text = f"""
🤖 <b>Auto Trade Setup - Confirmation</b>

📋 <b>Your Configuration:</b>

🔤 <b>Symbols:</b> {', '.join(symbols)}
🎯 <b>Strategies:</b> {strategy}
⚖️ <b>Risk Level:</b> {risk_display}

✅ <b>Ready to start automated trading?</b>

🚀 The system will:
• Monitor selected symbols continuously
• Execute trades automatically
• Manage risk according to your settings
• Send you real-time notifications
        """
        
        keyboard = self._create_confirmation_keyboard("auto")
        await callback.message.edit_text(text, reply_markup=keyboard, parse_mode='HTML')

    # ==================== SIGNAL MODE WIZARD FLOW ====================
    async def _show_signal_symbols_step(self, callback: CallbackQuery, state: FSMContext):
        """Step 1: Select symbols for Signal Mode"""
        text = """
📡 <b>Signal Mode Setup - Step 1/4</b>

🔤 <b>Select Trading Symbols</b>

Choose the symbols you want to monitor:
        """
        
        # Retrieve currently selected symbols to display toggle state
        data = await state.get_data()
        selected = data.get('signal_symbols', [])
        keyboard = self._create_symbols_keyboard("signal", selected)
        await callback.message.edit_text(text, reply_markup=keyboard, parse_mode='HTML')

    async def _show_signal_frequency_step(self, callback: CallbackQuery, state: FSMContext):
        """Step 2: Select frequency for Signal Mode"""
        # Get selected symbols from state
        data = await state.get_data()
        symbols = data.get('signal_symbols', [])
        
        text = f"""
📡 <b>Signal Mode Setup - Step 2/4</b>

✅ <b>Selected Symbols:</b> {', '.join(symbols)}

⏰ <b>Select Check Frequency</b>

How often should we check for signals?
        """
        
        keyboard = self._create_frequency_keyboard()
        await callback.message.edit_text(text, reply_markup=keyboard, parse_mode='HTML')

    async def _show_signal_confidence_step(self, callback: CallbackQuery, state: FSMContext):
        """Step 3: Select confidence for Signal Mode"""
        # Get previous selections
        data = await state.get_data()
        symbols = data.get('signal_symbols', [])
        frequency = data.get('signal_frequency', 'Not selected')
        
        freq_display = {
            '1m': '1 Minute',
            '5m': '5 Minutes',
            '15m': '15 Minutes',
            '1h': '1 Hour',
            '4h': '4 Hours'
        }.get(frequency, frequency)
        
        text = f"""
📡 <b>Signal Mode Setup - Step 3/4</b>

✅ <b>Symbols:</b> {', '.join(symbols)}
✅ <b>Frequency:</b> {freq_display}

🎯 <b>Select Confidence Level</b>

Minimum signal quality threshold:
        """
        
        keyboard = self._create_confidence_keyboard()
        await callback.message.edit_text(text, reply_markup=keyboard, parse_mode='HTML')

    async def _show_signal_strategy_step(self, callback: CallbackQuery, state: FSMContext):
        """Step 4: Select strategy for Signal Mode"""
        # Get previous selections
        data = await state.get_data()
        symbols = data.get('signal_symbols', [])
        frequency = data.get('signal_frequency', 'Not selected')
        confidence = data.get('signal_confidence', 'Not selected')
        
        freq_display = {
            '1m': '1 Minute',
            '5m': '5 Minutes',
            '15m': '15 Minutes',
            '1h': '1 Hour',
            '4h': '4 Hours'
        }.get(frequency, frequency)
        
        # Handle special 'all' confidence option
        if confidence == 'all':
            conf_display = "Send All"
        else:
            conf_display = f"{float(confidence)*100:.0f}%+" if confidence != 'Not selected' else confidence
        
        text = f"""
📡 <b>Signal Mode Setup - Step 4/4</b>

✅ <b>Symbols:</b> {', '.join(symbols)}
✅ <b>Frequency:</b> {freq_display}
✅ <b>Confidence:</b> {conf_display}

🎯 <b>Select Signal Strategy</b>

Choose your signal generation algorithm:
        """
        
        # Retrieve selected strategies to display toggle state
        data = await state.get_data()
        selected_strategies = data.get('signal_strategies', [])
        keyboard = self._create_strategy_keyboard("signal", selected_strategies)
        await callback.message.edit_text(text, reply_markup=keyboard, parse_mode='HTML')

    async def _show_signal_confirmation_step(self, callback: CallbackQuery, state: FSMContext):
        """Final Step: Confirmation for Signal Mode"""
        # Get all selections
        data = await state.get_data()
        symbols = data.get('signal_symbols', [])
        frequency = data.get('signal_frequency', 'Not selected')
        confidence = data.get('signal_confidence', 'Not selected')
        # Display selected strategies (multiple possible)
        strategies = data.get('signal_strategies', [])
        strategy = ', '.join(strategies) if strategies else 'Not selected'
        
        freq_display = {
            '1m': '1 Minute',
            '5m': '5 Minutes',
            '15m': '15 Minutes',
            '1h': '1 Hour',
            '4h': '4 Hours'
        }.get(frequency, frequency)
        
        if confidence == 'all':
            conf_display = "Send All"
        else:
            conf_display = f"{float(confidence)*100:.0f}%+" if confidence != 'Not selected' else confidence
        
        text = f"""
📡 <b>Signal Mode Setup - Confirmation</b>

📋 <b>Your Configuration:</b>

🔤 <b>Symbols:</b> {', '.join(symbols)}
⏰ <b>Frequency:</b> {freq_display}
🎯 <b>Confidence:</b> {conf_display}
📈 <b>Strategies:</b> {strategy}

✅ <b>Ready to start signal monitoring?</b>

🔔 The system will:
• Monitor selected symbols at your chosen frequency
• Send alerts only for high-confidence signals
• Not execute any trades automatically
• Keep you informed of market opportunities
        """
        
        keyboard = self._create_confirmation_keyboard("signal")
        await callback.message.edit_text(text, reply_markup=keyboard, parse_mode='HTML')

    # ==================== KEYBOARD BUILDERS ====================
    def _create_symbols_keyboard(self, mode: str, selected: Optional[List[str]] = None) -> InlineKeyboardMarkup:
        """Create symbols selection keyboard with toggle capability."""
        builder = InlineKeyboardBuilder()
        selected = selected or []

        for symbol in Config.SYMBOLS:
            # Prefix selected symbols with a check mark
            prefix = "✅" if symbol in selected else "🔤"
            builder.row(InlineKeyboardButton(
                text=f"{prefix} {symbol}",
                callback_data=f"{mode}_symbol_{symbol}"
            ))
        # Confirm selection button
        builder.row(InlineKeyboardButton(text="✅ Confirm Selection", callback_data=f"{mode}_confirm_symbols"))
        # Back to main menu
        builder.row(InlineKeyboardButton(text="↩️ Back to Main", callback_data="main_back"))
        return builder.as_markup()

    def _create_strategy_keyboard(self, mode: str, selected: Optional[List[str]] = None) -> InlineKeyboardMarkup:
        """Create strategy selection keyboard with multi-select."""
        builder = InlineKeyboardBuilder()
        selected = selected or []

        for strategy in list_strategies():
            # Prefix selected strategies with a check mark
            prefix = "✅" if strategy in selected else "🎯"
            builder.row(InlineKeyboardButton(
                text=f"{prefix} {strategy}",
                callback_data=f"{mode}_strategy_{strategy}"
            ))
        # Confirm selection button
        builder.row(InlineKeyboardButton(text="✅ Confirm Strategy", callback_data=f"{mode}_confirm_strategy"))
        # Back button to previous step
        builder.row(InlineKeyboardButton(text="↩️ Back", callback_data=f"{mode}_back_symbols"))
        return builder.as_markup()

    def _create_risk_keyboard(self, mode: str) -> InlineKeyboardMarkup:
        """Create risk level selection keyboard"""
        builder = InlineKeyboardBuilder()
        
        risk_levels = [
            ("🟢 Low Risk (1% per trade)", "low"),
            ("🟡 Medium Risk (2% per trade)", "medium"), 
            ("🔴 High Risk (3% per trade)", "high")
        ]
        
        for text, risk in risk_levels:
            builder.row(InlineKeyboardButton(
                text=text,
                callback_data=f"{mode}_risk_{risk}"
            ))
        
        builder.row(InlineKeyboardButton(text="↩️ Back", callback_data=f"{mode}_back_strategy"))
        
        return builder.as_markup()

    def _create_frequency_keyboard(self) -> InlineKeyboardMarkup:
        """Create frequency selection keyboard"""
        builder = InlineKeyboardBuilder()
        
        frequencies = [
            ("⚡ 1 Minute", "1m"),
            ("🚀 5 Minutes", "5m"),
            ("📊 15 Minutes", "15m"),
            ("🕐 1 Hour", "1h"),
            ("📈 4 Hours", "4h")
        ]
        
        for text, freq in frequencies:
            builder.row(InlineKeyboardButton(
                text=text,
                callback_data=f"signal_freq_{freq}"
            ))
        
        builder.row(InlineKeyboardButton(text="↩️ Back", callback_data="signal_back_symbols"))
        
        return builder.as_markup()

    def _create_confidence_keyboard(self) -> InlineKeyboardMarkup:
        """Create confidence selection keyboard"""
        builder = InlineKeyboardBuilder()
        
        confidence_levels = [
            ("🎯 High (80%+)", "0.8"),
            ("📊 Medium (70%+)", "0.7"),
            ("🔍 Low (60%+)", "0.6"),
            ("📣 Send All Signals", "all")
        ]
        
        for text, conf in confidence_levels:
            builder.row(InlineKeyboardButton(
                text=text,
                callback_data=f"signal_conf_{conf}"
            ))
        
        builder.row(InlineKeyboardButton(text="↩️ Back", callback_data="signal_back_frequency"))
        
        return builder.as_markup()

    def _create_confirmation_keyboard(self, mode: str) -> InlineKeyboardMarkup:
        """Create confirmation keyboard"""
        builder = InlineKeyboardBuilder()
        
        builder.row(
            InlineKeyboardButton(text="✅ Start Now", callback_data=f"{mode}_start"),
            InlineKeyboardButton(text="🔄 Restart Setup", callback_data=f"main_{mode}")
        )
        builder.row(InlineKeyboardButton(text="↩️ Back", callback_data=f"{mode}_back_previous"))
        
        return builder.as_markup()

    # ==================== WIZARD HANDLERS ====================
    async def handle_auto_wizard(self, callback: CallbackQuery, state: FSMContext):
        """Handle Auto Trade Wizard steps"""
        await callback.answer()
        
        # Parse callback data into mode and action segments
        data_parts = callback.data.split('_')
        mode, action = data_parts[0], data_parts[1]
        # Retrieve current selections
        data = await state.get_data()
        
        if action == "symbol":
            # Toggle selected symbol
            symbol = data_parts[2]
            current = data.get('auto_symbols', [])
            if symbol in current:
                current.remove(symbol)
            else:
                current.append(symbol)
            await state.update_data(auto_symbols=current)
            # Stay on symbol selection step
            await state.set_state(AutoTradeWizard.select_symbols)
            await self._show_auto_symbols_step(callback, state)
        elif action == "confirm" and len(data_parts) > 2 and data_parts[2] == "symbols":
            # Confirm symbol selection, proceed to strategy step
            await state.set_state(AutoTradeWizard.select_strategy)
            await self._show_auto_strategy_step(callback, state)
        elif action == "strategy":
            # Toggle strategy selection
            strategy = data_parts[2]
            current = data.get('auto_strategies', [])
            if strategy in current:
                current.remove(strategy)
            else:
                current.append(strategy)
            await state.update_data(auto_strategies=current)
            await state.set_state(AutoTradeWizard.select_strategy)
            await self._show_auto_strategy_step(callback, state)
        elif action == "confirm" and len(data_parts) > 2 and data_parts[2] == "strategy":
            # Confirm strategy selection, proceed to risk step
            await state.set_state(AutoTradeWizard.select_risk)
            await self._show_auto_risk_step(callback, state)
        elif action == "risk":
            # Set risk level and move to confirmation
            risk = data_parts[2]
            await state.update_data(auto_risk=risk)
            await state.set_state(AutoTradeWizard.confirmation)
            await self._show_auto_confirmation_step(callback, state)
        elif action == "start":
            # Start auto trading
            await self._start_auto_trading(callback, state)
        elif action == "back" and len(data_parts) > 2:
            # Generic back handler
            target = data_parts[2]
            if target == "symbols":
                await state.set_state(AutoTradeWizard.select_symbols)
                await self._show_auto_symbols_step(callback, state)
            elif target == "strategy":
                await state.set_state(AutoTradeWizard.select_strategy)
                await self._show_auto_strategy_step(callback, state)
            elif target == "previous":
                await state.set_state(AutoTradeWizard.select_risk)
                await self._show_auto_risk_step(callback, state)
        elif action == "restart":
            # Restart selection: stop loops and return to first step
            await self._handle_restart(callback, state, 'auto')

    async def handle_signal_wizard(self, callback: CallbackQuery, state: FSMContext):
        """Handle Signal Mode Wizard steps"""
        await callback.answer()
        
        # Parse callback data
        data_parts = callback.data.split('_')
        mode, action = data_parts[0], data_parts[1]
        data = await state.get_data()
        
        if action == "symbol":
            # Toggle symbol selection
            symbol = data_parts[2]
            current = data.get('signal_symbols', [])
            if symbol in current:
                current.remove(symbol)
            else:
                current.append(symbol)
            await state.update_data(signal_symbols=current)
            await state.set_state(SignalModeWizard.select_symbols)
            await self._show_signal_symbols_step(callback, state)
        elif action == "confirm" and len(data_parts) > 2 and data_parts[2] == "symbols":
            # Confirm symbols, move to frequency
            await state.set_state(SignalModeWizard.select_frequency)
            await self._show_signal_frequency_step(callback, state)
        elif action == "freq":
            # Set frequency and go to confidence
            frequency = data_parts[2]
            await state.update_data(signal_frequency=frequency)
            await state.set_state(SignalModeWizard.select_confidence)
            await self._show_signal_confidence_step(callback, state)
        elif action == "conf":
            # Set confidence and go to strategy selection
            conf_value = data_parts[2]
            await state.update_data(signal_confidence=conf_value)
            await state.set_state(SignalModeWizard.select_strategy)
            await self._show_signal_strategy_step(callback, state)
        elif action == "strategy":
            # Toggle strategy selection
            strategy = data_parts[2]
            current = data.get('signal_strategies', [])
            if strategy in current:
                current.remove(strategy)
            else:
                current.append(strategy)
            await state.update_data(signal_strategies=current)
            await state.set_state(SignalModeWizard.select_strategy)
            await self._show_signal_strategy_step(callback, state)
        elif action == "confirm" and len(data_parts) > 2 and data_parts[2] == "strategy":
            # Confirm strategies, go to confirmation summary
            await state.set_state(SignalModeWizard.confirmation)
            await self._show_signal_confirmation_step(callback, state)
        elif action == "start":
            # Start monitoring
            await self._start_signal_monitoring(callback, state)
        elif action == "back" and len(data_parts) > 2:
            target = data_parts[2]
            if target == "symbols":
                await state.set_state(SignalModeWizard.select_symbols)
                await self._show_signal_symbols_step(callback, state)
            elif target == "frequency":
                await state.set_state(SignalModeWizard.select_frequency)
                await self._show_signal_frequency_step(callback, state)
            elif target == "previous":
                await state.set_state(SignalModeWizard.select_strategy)
                await self._show_signal_strategy_step(callback, state)
        elif action == "restart":
            await self._handle_restart(callback, state, 'signal')

    # ==================== EXECUTION METHODS ====================
    async def _start_auto_trading(self, callback: CallbackQuery, state: FSMContext):
        """Start auto trading with selected parameters"""
        try:
            data = await state.get_data()
            symbols = data.get('auto_symbols', [])
            strategies = data.get('auto_strategies', [])
            risk = data.get('auto_risk', 'medium')
            # Start loops concurrently for each symbol-strategy combination
            tasks = []
            for symbol in symbols:
                for strat in strategies:
                    tasks.append(self.signal_engine.start_signal_loop(
                        user_id=callback.from_user.id,
                        strategy=strat,
                        symbol=symbol,
                        timeframe="5m",
                        min_confidence=0.7,
                        interval_minutes=2,
                        on_signal=self._on_auto_trade_signal,
                        on_no_signal=self._on_no_signal
                    ))
            # gather results
            started_loops = []
            if tasks:
                results = await asyncio.gather(*tasks)
                started_loops = [r for r in results if r]
            # Build success message
            strategies_display = ', '.join(strategies) if strategies else 'None'
            success_text = f"""
✅ <b>Auto Trading Started Successfully!</b>

🤖 <b>Active Configuration:</b>
• <b>Symbols:</b> {', '.join(symbols)}
• <b>Strategies:</b> {strategies_display}
• <b>Risk Level:</b> {risk.title()}
• <b>Monitoring:</b> {len(started_loops)} loop(s)

🚀 <b>System Status: ACTIVE</b>

The bot is now monitoring markets and will execute trades automatically based on your strategy settings.

📊 <i>You will receive trade execution notifications in this chat.</i>
            """
            # Provide restart button
            kb = InlineKeyboardBuilder()
            kb.row(InlineKeyboardButton(text="🔄 Restart Selection", callback_data="auto_restart"))
            kb.row(InlineKeyboardButton(text="↩️ Back to Main", callback_data="main_back"))
            await callback.message.edit_text(success_text, reply_markup=kb.as_markup(), parse_mode='HTML')
            await state.clear()
            
        except Exception as e:
            logger.error(f"❌ Error starting auto trading: {e}")
            await callback.message.answer("❌ Error starting auto trading")

    async def _start_signal_monitoring(self, callback: CallbackQuery, state: FSMContext):
        """Start signal monitoring with selected parameters"""
        try:
            data = await state.get_data()
            symbols = data.get('signal_symbols', [])
            strategies = data.get('signal_strategies', [])
            frequency = data.get('signal_frequency', '5m')
            confidence_value = data.get('signal_confidence', '0.7')
            # Determine minimum confidence; 'all' disables filtering by passing None
            if confidence_value == 'all':
                min_conf = None
                conf_display = 'Send All Signals'
            else:
                # interpret as a decimal fraction (0.7 = 70%)
                min_conf = float(confidence_value)
                conf_display = f"{float(confidence_value)*100:.0f}%+"
            # Start loops concurrently for each symbol-strategy combination
            tasks = []
            for symbol in symbols:
                for strat in strategies:
                    tasks.append(self.signal_engine.start_signal_loop(
                        user_id=callback.from_user.id,
                        strategy=strat,
                        symbol=symbol,
                        timeframe=frequency,
                        min_confidence=min_conf,
                        interval_minutes=self._frequency_to_minutes(frequency),
                        on_signal=self._on_signal_alert,
                        on_no_signal=self._on_no_signal
                    ))
            started_signals = []
            if tasks:
                results = await asyncio.gather(*tasks)
                started_signals = [r for r in results if r]
            strategies_display = ', '.join(strategies) if strategies else 'None'
            success_text = f"""
✅ <b>Signal Monitoring Started Successfully!</b>

📡 <b>Active Configuration:</b>
• <b>Symbols:</b> {', '.join(symbols)}
• <b>Strategies:</b> {strategies_display}
• <b>Frequency:</b> {frequency}
• <b>Confidence:</b> {conf_display}
• <b>Monitoring:</b> {len(started_signals)} loop(s)

🔔 <b>System Status: ACTIVE</b>

The bot is now monitoring markets and will send you signal alerts when qualified opportunities are detected.

📨 <i>You will receive signal alerts in this chat (no trades will be executed).</i>
            """
            # Provide restart button
            kb = InlineKeyboardBuilder()
            kb.row(InlineKeyboardButton(text="🔄 Restart Selection", callback_data="signal_restart"))
            kb.row(InlineKeyboardButton(text="↩️ Back to Main", callback_data="main_back"))
            await callback.message.edit_text(success_text, reply_markup=kb.as_markup(), parse_mode='HTML')
            await state.clear()
            
        except Exception as e:
            logger.error(f"❌ Error starting signal monitoring: {e}")
            await callback.message.answer("❌ Error starting signal monitoring")

    # ==================== PORTFOLIO & REPORTS ====================
    async def _show_portfolio_menu(self, callback: CallbackQuery):
        """Show portfolio menu"""
        menu_text = """
💼 <b>Portfolio Overview</b>

📊 Real-time portfolio tracking will be available here.

• Live positions and PnL
• Risk exposure analysis  
• Trade history
• Performance metrics
        """
        
        keyboard = self._create_simple_back_keyboard()
        await callback.message.edit_text(menu_text, reply_markup=keyboard, parse_mode='HTML')

    async def _show_reports_menu(self, callback: CallbackQuery):
        """Show reports menu"""
        menu_text = """
📊 <b>Performance Reports</b>

📈 Comprehensive analytics will be available here.

• Strategy performance
• Portfolio analytics
• Trade execution history
• Risk metrics and exposure
        """
        
        keyboard = self._create_simple_back_keyboard()
        await callback.message.edit_text(menu_text, reply_markup=keyboard, parse_mode='HTML')

    def _create_simple_back_keyboard(self) -> InlineKeyboardMarkup:
        """Create simple back to main keyboard"""
        builder = InlineKeyboardBuilder()
        builder.row(InlineKeyboardButton(text="↩️ Back to Main", callback_data="main_back"))
        return builder.as_markup()

    async def handle_other_menus(self, callback: CallbackQuery):
        """Handle portfolio and reports menus"""
        await callback.answer("Feature coming soon!")

    # ==================== HELPER METHODS ====================
    def _frequency_to_minutes(self, frequency: str) -> int:
        """Convert frequency string to minutes"""
        freq_map = {'1m': 1, '5m': 5, '15m': 15, '1h': 60, '4h': 240}
        return freq_map.get(frequency, 5)

    async def _on_auto_trade_signal(self, user_id: int, signal):
        """Handle auto-trade signals.

        When a new signal is generated for auto trading, this callback
        receives the ``user_id`` and the ``Signal`` dataclass.  At the
        moment we simply log the event; the execution of trades is handled
        by the main bot callback in ``run_bot.py``.  This placeholder can be
        extended to perform per-user custom actions.
        """
        logger.info(f"🎯 Auto trade signal: {signal.direction} {signal.symbol}")

    async def _on_signal_alert(self, user_id: int, signal):
        """Handle signal alerts.

        This callback is used in signal monitoring mode where trades are not
        executed.  It logs the signal information; you could extend this
        method to forward alerts to Telegram or other notification systems.
        """
        logger.info(f"🔔 Signal alert: {signal.direction} {signal.symbol}")
    async def _on_no_signal(self, user_id: int, symbol: str, timeframe: str, message: str):
        """Called when no signal is generated for a symbol/timeframe."""
        from src.utils.logger import setup_logger as _setup_logger
        _log = _setup_logger("no_signal")
        _log.info(f"No signal → {symbol} {timeframe}: {message}")
        _log.debug(f"📊 No signal for {symbol}")

    async def _handle_restart(self, callback: CallbackQuery, state: FSMContext, mode: str):
        """
        Handle restart selection: stop all active loops for the user and reset the wizard.
        """
        try:
            # Stop all active signal loops for this user
            await self.signal_engine.stop(callback.from_user.id)
        except Exception as e:
            logger.error(f"Error stopping signal loops on restart: {e}")
        # Clear state
        await state.clear()
        # Reset wizard state based on mode
        if mode == 'auto':
            await state.set_state(AutoTradeWizard.select_symbols)
            await self._show_auto_symbols_step(callback, state)
        else:
            await state.set_state(SignalModeWizard.select_symbols)
            await self._show_signal_symbols_step(callback, state)

    async def help_command(self, message: Message):
        """Handle /help command"""
        help_text = """
🆘 <b>WIF Trading Bot - Help</b>

<b>Step-by-Step Setup:</b>
• Choose Auto Trade or Signal Mode
• Follow the wizard steps one by one
• Configure your preferences
• Start monitoring/trading

<b>Features:</b>
• 🤖 Auto Trade - Automated trading with execution
• 📡 Signal Mode - Signal alerts only
• 💼 Portfolio - Position tracking
• 📊 Reports - Performance analytics
        """
        
        keyboard = self._create_main_menu_keyboard()
        await message.answer(help_text, reply_markup=keyboard, parse_mode='HTML')

    async def ping_command(self, message: Message):
        """
        Simple health check command.

        Responds with ``OK`` and the number of active signal loops for the
        requesting user.  This can be used by monitoring systems to ensure
        the bot is responsive.
        """
        try:
            # Determine active loops for this user
            user_id = message.from_user.id
            count = self.signal_engine.active_loop_count(user_id)
            await message.answer(f"OK {count}")
        except Exception as e:
            logger.error(f"Error in ping handler: {e}")
            await message.answer("Error")